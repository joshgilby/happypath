# Quelaag Decision Log

Append-only. Each entry is `## YYYY-MM-DD — title` with a **Decision** and a ~two-line
**Why**. Entries are never edited or deleted; a later entry may name and supersede an
earlier one.

## 2026-08-04 — Verification stack

**Decision**: The verification service, verification library, and secrets vault are
built in JavaScript on Node, with Express as the service basis.

**Why**: Node's built-in cryptographic library carries both the hashing in the
verification library and the encryption in the secrets vault with no third-party
dependencies, and Express is a minimal, widely known foundation for a small service.

## 2026-08-04 — Assurance stack

**Decision**: The assurance engine is built in Python, with FastAPI as its service
framework.

**Why**: Python is the everyday language of network automation, and a second stack
beside the Node one makes the series' technology-diversity theme concrete rather than
claimed.

## 2026-08-04 — Inventory tooling

**Decision**: The assurance engine uses nornir for its device inventory.

**Why**: nornir's pluggable inventory keeps the planned integration with an external
NSoT (roadmap backlog) a one-component change, and it introduces readers to a widely
used automation tool.

## 2026-08-04 — Lab technology

**Decision**: Lab devices are Cisco IOL images, obtained by each reader through
Cisco's free CML tier, run under containerlab.

**Why**: IOL is the only IOS-XE image a reader can get at no cost, and it is light
enough for a multi-device network lab on a laptop. Caveat: the images are licensed
for use within CML and this project never redistributes them — each reader downloads
the reference platform ISO with their own Cisco account.

## 2026-08-04 — Syslog receiver stack

**Decision**: The syslog receiver is built in Python, alongside the assurance engine
it calls.

**Why**: The receiver is a thin adapter with no cryptographic needs, so sharing the
assurance engine's stack keeps it simple. Milestone 6 may revisit this.

## 2026-08-04 — Documentation formats

**Decision**: Project documents are Markdown with Mermaid diagrams; the decision log
and the glossary are each a single file.

**Why**: Everything renders on GitHub with no toolchain for the reader to install,
and a single file reads start to finish like a story.

## 2026-08-04 — Connection-script tooling

**Decision**: The first connection script uses Python with netmiko; dependencies are
managed with uv (declared in pyproject.toml, locked transitively in uv.lock).

**Why**: netmiko is the device-SSH library most readers already know, and reads as
straight-line beginner code. uv pins the whole dependency tree and turns environment
setup into a single `uv run`. nornir waits for the assurance engine (Milestone 5).

## 2026-08-04 — Lab shape and addressing

**Decision**: The network lab is two lab devices, r1 and r2, with one data link; the
management network is 192.0.2.0/24 (RFC 5737) with static addresses .11 and .12.

**Why**: Two devices are the smallest fleet that lets later milestones show
per-device behavior, inside a laptop's memory budget. Documentation-range addressing
means every address a reader ever sees is publication-safe.

## 2026-08-04 — Baseline configuration delivery

**Decision**: Each device's baseline configuration is a containerlab *partial*
config (`configs/rN.partial.cfg`) carrying only the type-8 local users and SCP;
containerlab's own template supplies the hostname, management VRF and addressing,
and SSH keys.

**Why**: containerlab's cisco_iol kind generates a complete device configuration and
merges a `.partial` file into it — supplying a full config replaces that template and
leaves the device with no management address. Keeping the baseline to the milestone's
actual subject also makes it quotable in the article.

## 2026-08-04 — Type-8 parameters

**Decision**: A type-8 secret is `$8$<salt>$<digest>`: PBKDF2-HMAC-SHA256 over the
plaintext, 20,000 iterations, 32-byte output, with the salt's 14 characters used as
ASCII bytes and the result encoded in the alphabet
`./0123456789A-Za-z` without padding.

**Why**: Confirmed by reproducing two hashes taken from lab devices, not taken from
documentation. Two details break from-scratch implementations and are easy to get
wrong: the salt is **not** base64-decoded before use (decoding produces a
plausible-looking hash that no device accepts), and the alphabet is **not** standard
base64 — it starts `./` and omits `+/`.

## 2026-08-04 — JavaScript project layout and test runner

**Decision**: JavaScript lives in `verification/` with no runtime dependencies, using
ES modules and Node's built-in test runner (`node --test`) via `npm test`.

**Why**: The directory grows into the verification service that owns the library and
the vault, matching the design. Node's built-in crypto and test runner mean a reader
installs nothing — the same reproducibility argument that chose uv on the Python side.

## 2026-08-05 — Service basis

**Decision**: The verification service is built on Node's own HTTP server, with no
runtime dependencies.

**Why**: The service needs one route pair and one body parse, which Node handles in a
few lines — so a framework would have bought familiarity rather than capability, at
the cost of the project's zero-dependency property. Keeping that property through the
first networked component is what lets a reader still install nothing but Node. The
trade is real: readers who reach for Express by reflex will not find it, and twenty
lines of routing stay visible that a framework would have hidden.

**Supersedes**: 2026-08-04 — Verification stack, in its choice of Express as the
service basis. That entry's language and cryptography choices stand.

## 2026-08-04 — Vault encryption

**Decision**: The secrets vault is a single AES-256-GCM payload holding all entries,
keyed by scrypt from the operator's passphrase and a random salt stored in the file,
written as a JSON envelope of four base64 fields: `salt`, `iv`, `tag`, `data`. Each
write uses a fresh initialisation vector and goes to a temporary file renamed into
place.

**Why**: Encrypting everything together hides which devices and accounts exist, not
just their secrets. GCM's authentication tag is what makes a wrong key fail
distinctly — the cipher detects it, so the code adds a message rather than a
detection mechanism. A rename is atomic, so an interrupted write cannot destroy the
vault, which is the system's source of truth.

## 2026-08-04 — How the vault key and secrets are supplied

**Decision**: The vault passphrase arrives in the environment variable
`QUELAAG_VAULT_KEY`; secrets arrive on standard input. Neither is ever a command-line
argument.

**Why**: On Linux a process's command line is readable by every user on the host,
while its environment is readable only by the owning account. Stdin for secrets
matches the pattern the verification CLI already uses. How a long-running service
obtains the key is deliberately left to Milestone 4 — the vault takes the key on
every call rather than holding it, which keeps that choice open.

## 2026-08-04 — Articles are written after the software

**Decision**: The article for each milestone is written once the whole software
project is complete, not alongside its milestone. Milestones still deliver
article-shaped material — a runnable increment, story-shaped commits, and recorded
rationale — but no prose article is a milestone deliverable.

**Why**: Writing the series at the end lets each article draw on how the system
actually turned out, and keeps the build from stalling on prose. The material that
is expensive to reconstruct later (decisions, vocabulary, commit order) is already
captured as it happens.

## 2026-08-04 — Device file transfer uses `unix:`

**Decision**: File transfers to lab devices target the `unix:` filesystem; SCP needs
no AAA configuration beyond the stock baseline.

**Why**: IOL has no `flash:` — its writable default filesystem is `unix:`, and a
transfer aimed at `flash:` fails with a misleading "Write failed". Transfers also
need `scp -O`, since modern OpenSSH defaults to SFTP, which IOS does not serve.
Verified by round-trip transfer with `no aaa new-model` in place.

## 2026-08-04 — Setup-command shape

**Decision**: The lab starts and stops with two tiny shell scripts, lab/up.sh and
lab/down.sh, wrapping containerlab.

**Why**: A script is the most literal "single documented command", adds no new tool
for the reader, and is short enough to print in the article in full.

## 2026-08-05 — Rebooting a lab device

**Decision**: A device is rebooted with `scripts/reboot_device.py`, which reloads IOS in
place. `docker restart` is not used, and a redeploy is not a reboot.

**Why**: Restarting the container leaves `iol.bin` running without `iouyap`, the daemon
bridging the device's interfaces to `eth0`, and destroys the data-link veth — the device
boots fine and is simply unwired, which looks exactly like a hang. A redeploy deletes
each node's NVRAM and rebuilds from the baseline partial, so it resets the device by
construction. Reloading IOS leaves the container and its plumbing untouched, which is
the only genuine reboot this lab can offer.

