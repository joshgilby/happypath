"""Prove the verification library and a real device agree about type-8 hashes.

Generates a hash with the library, configures it on a throwaway account, logs in
with the original plaintext, and removes the account again.

Usage: uv run scripts/roundtrip_check.py r1
"""

import subprocess
import sys

from netmiko import ConnectHandler

DEVICES = {
    "r1": "192.0.2.11",
    "r2": "192.0.2.12",
}

ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "CHANGE-ME-ADMIN"

# The throwaway account exists only while this script runs (lab/README.md).
TEST_USERNAME = "roundtrip"
TEST_PASSWORD = "CHANGE-ME-ROUNDTRIP"


def generate_hash(plaintext):
    # The plaintext goes in on stdin: an argument would be visible to every user
    # on this host in the process table.
    result = subprocess.run(
        ["node", "verification/src/cli.js"],
        input=plaintext,
        capture_output=True,
        text=True,
    )
    return result.stdout.strip()


def connect(host, username, password):
    return ConnectHandler(
        device_type="cisco_xe", host=host, username=username, password=password
    )


def main():
    host = DEVICES[sys.argv[1]]
    secret_hash = generate_hash(TEST_PASSWORD)
    print(f"generated {secret_hash}")

    admin = connect(host, ADMIN_USERNAME, ADMIN_PASSWORD)
    admin.send_config_set([f"username {TEST_USERNAME} privilege 1 secret 8 {secret_hash}"])
    print(f"configured {TEST_USERNAME} on {sys.argv[1]}")

    test_session = connect(host, TEST_USERNAME, TEST_PASSWORD)
    print(f"logged in as {TEST_USERNAME}: the device accepts the library's hash")
    test_session.disconnect()

    # Removing a username asks "Do you want to continue? [confirm]"; the empty
    # line answers it.
    admin.send_config_set([f"no username {TEST_USERNAME}", ""], cmd_verify=False)
    admin.disconnect()
    print(f"removed {TEST_USERNAME}")


if __name__ == "__main__":
    main()
