import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

import { generateSecret, verifySecret } from "../src/secrets.js";

const fixtures = JSON.parse(
  readFileSync(new URL("./fixtures/device-hashes.json", import.meta.url)),
).entries;

test("every device hash verifies against its own plaintext", () => {
  for (const entry of fixtures) {
    assert.equal(
      verifySecret("type8", entry.plaintext, entry.hash),
      true,
      `${entry.device} ${entry.username} should verify`,
    );
  }
});

test("no device hash verifies against another plaintext", () => {
  const plaintexts = [...new Set(fixtures.map((entry) => entry.plaintext))];
  for (const entry of fixtures) {
    for (const other of plaintexts.filter((p) => p !== entry.plaintext)) {
      assert.equal(
        verifySecret("type8", other, entry.hash),
        false,
        `${entry.device} ${entry.username} should reject ${other}`,
      );
    }
  }
});

test("the same secret has different hashes on different devices", () => {
  const r1 = fixtures.find((e) => e.device === "r1" && e.username === "admin");
  const r2 = fixtures.find((e) => e.device === "r2" && e.username === "admin");

  assert.equal(r1.plaintext, r2.plaintext);
  assert.notEqual(r1.hash, r2.hash);
  assert.equal(verifySecret("type8", r1.plaintext, r1.hash), true);
  assert.equal(verifySecret("type8", r2.plaintext, r2.hash), true);
});

test("a generated hash verifies against the secret it came from", () => {
  const hash = generateSecret("type8", "CHANGE-ME-ADMIN");

  assert.equal(verifySecret("type8", "CHANGE-ME-ADMIN", hash), true);
  assert.equal(verifySecret("type8", "CHANGE-ME-OPERATOR", hash), false);
});

test("a generated hash looks like the ones devices produce", () => {
  const generated = generateSecret("type8", "CHANGE-ME-ADMIN").split("$");
  const fromDevice = fixtures[0].hash.split("$");

  assert.deepEqual(generated.slice(0, 2), fromDevice.slice(0, 2));
  assert.equal(generated[2].length, fromDevice[2].length);
  assert.equal(generated[3].length, fromDevice[3].length);
  assert.match(generated[2] + generated[3], /^[./0-9A-Za-z]+$/);
});

test("hashing one secret twenty times gives twenty distinct hashes", () => {
  const hashes = [];
  for (let i = 0; i < 20; i += 1) {
    hashes.push(generateSecret("type8", "CHANGE-ME-ADMIN"));
  }

  assert.equal(new Set(hashes).size, 20);
  for (const hash of hashes) {
    assert.equal(verifySecret("type8", "CHANGE-ME-ADMIN", hash), true);
  }
});
