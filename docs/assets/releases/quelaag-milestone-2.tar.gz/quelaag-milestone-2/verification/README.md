# Verification

Generates and verifies the secret hashes network devices store. This is the first
piece of quelaag's JavaScript side; the vault and the verification service grow here
in later milestones.

```sh
npm test        # the whole suite, no lab required
```

## Reading a `$8$` string

Ask a Cisco device for its configuration and the local users look like this:

```text
username admin privilege 15 secret 8 $8$6MDQWLA4JAG.pU$2NYhnsjdrF.A2jgvUlpYU9DYJvSHgxAND7unfHGB7WY
```

The password itself is not in there. What you are looking at has three parts,
separated by `$`:

| Part | Example | What it is |
|------|---------|------------|
| `8` | `8` | the format — Cisco's type 8 |
| salt | `6MDQWLA4JAG.pU` | 14 random characters, chosen when the password was set |
| digest | `2NYhnsjdrF.A2jg…` | the result of scrambling the password together with that salt |

The scrambling is PBKDF2 with SHA-256, repeated 20,000 times. It only runs one way:
from the digest you cannot work backwards to the password. What you *can* do is take
a password you suspect is right, scramble it with the same salt, and see whether you
land on the same digest. That is all verification is.

## Why the same password gives a different hash every time

The salt is new every time a password is set. Set the same password on two devices —
or twice on one device — and the salts differ, so the digests differ:

```text
r1: $8$6MDQWLA4JAG.pU$2NYhnsjdrF.A2jgvUlpYU9DYJvSHgxAND7unfHGB7WY
r2: $8$q9UXTeTb16P/M.$p3NFLlH4GzfJzejNAywIiHqPsPsP6AoIlKLm4wpGsf.
```

Both are `CHANGE-ME-ADMIN`. This is deliberate: if hashes were identical for
identical passwords, anyone who stole a configuration could spot which accounts share
a password, and could precompute a giant table of common passwords once and look up
every device against it. The salt makes that table useless, because it would have to
be rebuilt for every salt.

The consequence for us: **you can never compare two hashes to each other.** Asking
"is this the right password?" always means deriving a fresh digest with the stored
salt and comparing that. `verifySecret` does exactly this, and compares in constant
time so that how long the answer takes cannot betray how much of the digest matched.

## The two details that trip up implementations

Both were found by reproducing real device hashes, and both produce a
plausible-looking hash that no device will ever accept:

1. **The salt is not decoded.** Those 14 characters look like base64, and an 80-bit
   salt would indeed encode to 14 characters — so it is tempting to decode them back
   to 10 raw bytes and feed those to PBKDF2. Cisco does not. The 14 characters are
   used as-is, as ASCII.
2. **The alphabet is not standard base64.** Cisco encodes with
   `./0123456789A-Za-z` — it begins with `./` and has no `+` or `/` at the end.
   Standard base64 output has to be translated across, and its `=` padding dropped.

## Supported formats

`type8` is the only format today, and every call names it explicitly:

```js
verifySecret("type8", plaintext, hash);
generateSecret("type8", plaintext);
```

The format is never guessed from the hash string. Support for other formats — type 5,
type 9, other vendors — is on the [roadmap backlog](../docs/roadmap.md); naming the
format at every call is what will let one be added without changing a single existing
caller.
