// Prints a type-8 hash for the secret given on standard input.
//
// The secret arrives on stdin rather than as an argument because command lines
// are visible to every user on the host through the process table.
//
//   printf 'the-secret' | node verification/src/cli.js

import { generateSecret } from "./secrets.js";

const chunks = [];
for await (const chunk of process.stdin) {
  chunks.push(chunk);
}

console.log(generateSecret("type8", chunks.join("")));
