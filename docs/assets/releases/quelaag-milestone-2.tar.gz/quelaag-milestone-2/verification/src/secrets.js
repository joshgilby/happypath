import { pbkdf2Sync, randomInt, timingSafeEqual } from "node:crypto";

const ITERATIONS = 20000;
const KEY_LENGTH = 32;
const SALT_LENGTH = 14;

// Cisco encodes with this alphabet rather than standard base64: it starts with
// "./" and has no "+" or "/" at the end. Standard base64 output is translated
// into it character by character.
const CISCO_ALPHABET =
  "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
const STANDARD_ALPHABET =
  "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

function toCiscoBase64(bytes) {
  const standard = bytes.toString("base64").replace(/=+$/, "");
  return [...standard]
    .map((character) => CISCO_ALPHABET[STANDARD_ALPHABET.indexOf(character)])
    .join("");
}

function digestFor(plaintext, salt) {
  // The salt's characters are the salt bytes. They are NOT base64-decoded first;
  // decoding produces a valid-looking hash that no device will ever accept.
  const derived = pbkdf2Sync(plaintext, salt, ITERATIONS, KEY_LENGTH, "sha256");
  return toCiscoBase64(derived);
}

export function generateSecret(format, plaintext) {
  const salt = Array.from(
    { length: SALT_LENGTH },
    () => CISCO_ALPHABET[randomInt(CISCO_ALPHABET.length)],
  ).join("");

  return `$8$${salt}$${digestFor(plaintext, salt)}`;
}

export function verifySecret(format, plaintext, hash) {
  const [, , salt, digest] = hash.split("$");
  const candidate = Buffer.from(digestFor(plaintext, salt));
  const stored = Buffer.from(digest);

  // Comparing byte by byte with === would leak, through how long it takes, how
  // much of the digest matched.
  return (
    candidate.length === stored.length && timingSafeEqual(candidate, stored)
  );
}
