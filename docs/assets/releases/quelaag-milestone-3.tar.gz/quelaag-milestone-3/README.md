# quelaag

Tool to maintain secrets on network devices.

Quelaag watches the secrets configured on network devices and puts the known-good
value back when one changes — automatically, with no human in the loop. It is built
as a set of small cooperating services and doubles as an article series about
microservice architecture in network automation.

- **Get started**: [lab/README.md](lab/README.md) — run the two-device lab on your
  laptop
- **Verification**: [verification/README.md](verification/README.md) — what a `$8$`
  secret is, the library that reads and writes them, and the encrypted vault holding
  the secrets they are checked against
- **The design**: [docs/design.md](docs/design.md) — the whole system on one page
- **The plan**: [docs/roadmap.md](docs/roadmap.md) — milestones, one article each
