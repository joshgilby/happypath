# Quelaag Decision Log

Append-only. Each entry is `## YYYY-MM-DD — title` with a **Decision** and a ~two-line
**Why**. Entries are never edited or deleted; a later entry may name and supersede an
earlier one.

## 2026-08-04 — Verification stack

**Decision**: The verification service, verification library, and secrets vault are
built in JavaScript on Node, with Express as the service basis.

**Why**: Node's built-in cryptographic library carries both the hashing in the
verification library and the encryption in the secrets vault with no third-party
dependencies, and Express is a minimal, widely known foundation for a small service.

## 2026-08-04 — Assurance stack

**Decision**: The assurance engine is built in Python, with FastAPI as its service
framework.

**Why**: Python is the everyday language of network automation, and a second stack
beside the Node one makes the series' technology-diversity theme concrete rather than
claimed.

## 2026-08-04 — Inventory tooling

**Decision**: The assurance engine uses nornir for its device inventory.

**Why**: nornir's pluggable inventory keeps the planned integration with an external
NSoT (roadmap backlog) a one-component change, and it introduces readers to a widely
used automation tool.

## 2026-08-04 — Lab technology

**Decision**: Lab devices are Cisco IOL images, obtained by each reader through
Cisco's free CML tier, run under containerlab.

**Why**: IOL is the only IOS-XE image a reader can get at no cost, and it is light
enough for a multi-device network lab on a laptop. Caveat: the images are licensed
for use within CML and this project never redistributes them — each reader downloads
the reference platform ISO with their own Cisco account.

## 2026-08-04 — Syslog receiver stack

**Decision**: The syslog receiver is built in Python, alongside the assurance engine
it calls.

**Why**: The receiver is a thin adapter with no cryptographic needs, so sharing the
assurance engine's stack keeps it simple. Milestone 6 may revisit this.

## 2026-08-04 — Documentation formats

**Decision**: Project documents are Markdown with Mermaid diagrams; the decision log
and the glossary are each a single file.

**Why**: Everything renders on GitHub with no toolchain for the reader to install,
and a single file reads start to finish like a story.
