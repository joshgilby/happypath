# Quelaag Glossary

Alphabetized; exactly one term per concept, format `**term** — definition`. Code,
documents, and article prose use these terms verbatim.

- **assurance** — bringing a device's configured secrets back in line with their
  known-good values: fetch the configuration, verify each secret, correct what fails.
- **assurance engine** — the service that performs assurance for a device; it talks to
  devices and to the verification service.
- **detect-and-correct cycle** — one complete pass of the system, from a device's
  config-change syslog message to the corrected configuration coming to rest.
- **inventory** — the record of which devices quelaag manages and how to reach them.
- **lab device** — one emulated network device inside the network lab.
- **network lab** — the emulated network that stands in for production: the set of lab
  devices quelaag manages.
- **NSoT** — network source of truth: an external system that owns authoritative
  network data, such as the device inventory (a roadmap backlog integration).
- **secret** — a confidential configured value on a device, such as a local user
  password; kept as plaintext only inside the secrets vault, and appearing on devices
  only as a hash.
- **secrets vault** — the encrypted store of known-good secrets on local disk, owned
  exclusively by the verification service.
- **syslog** — the standard protocol network devices use to report events, including
  configuration changes, to a remote listener.
- **syslog receiver** — the service that listens for config-change syslog messages and
  sends the assurance engine an assurance request for the changed device.
- **type-8 hash** — Cisco's PBKDF2-SHA256 password hash format, written as an `$8$`
  string in device configurations.
- **verification library** — the library, embedded in the verification service, that
  generates and verifies hashes (type-8 first, format-aware for later formats).
- **verification service** — the service that answers whether a hash is correct for a
  given service and username, and issues correct replacement hashes.
- **verify** — to check a configured hash against its known-good secret. This is the
  project's single verb for that action; "validate" is not used.
