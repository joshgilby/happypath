# quelaag — the design, before any code

Tool to maintain secrets on network devices: local user passwords, enable secrets,
SNMP communities and shared keys, kept current across a fleet.

This download is the paper trail from **article 0**, and nothing in it runs. There is
no code at this point in the project — that is the point of the article.

- `docs/roadmap.md`   — the seven milestones the series builds through
- `docs/decisions.md` — the decision log, append-only, superseded entries kept
- `docs/glossary.md`  — one term per concept, used verbatim in code and prose

The design itself is the article; it is not duplicated here.

Every later article ships an archive you can actually run. The next one builds a
two-device lab on your laptop.
