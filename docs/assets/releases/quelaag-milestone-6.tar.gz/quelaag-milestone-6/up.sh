#!/bin/sh
# Start the whole system: the lab, then the services that watch it.
#
# The order is not a style choice. Compose attaches to a network containerlab creates, so
# the lab has to exist first. Each step is printed, because a convenience that hides what
# it ran leaves you unable to work out which part broke.
set -e
cd "$(dirname "$0")"

if [ ! -f .env ]; then
    echo "up.sh: no .env — copy .env.example to .env first" >&2
    exit 1
fi

# containerlab needs root, as it has since Milestone 1 — this step will ask for it.
echo "==> the lab (containerlab; needs sudo)"
./lab/up.sh

# Before compose, and as you rather than as root. Docker creates a missing bind source
# itself, but creates it owned by root — and then the vault command line cannot write to
# its own vault, on a clean checkout, with no obvious cause. Milestone 3 makes this
# directory the same way.
echo "==> the vault directory (~/.quelaag)"
mkdir -p -m 700 "$HOME/.quelaag"

echo "==> the services"
docker compose up -d --build

echo
echo "Up. Watch it with: docker compose logs -f"
echo "A run's findings appear under 'assurance'."
