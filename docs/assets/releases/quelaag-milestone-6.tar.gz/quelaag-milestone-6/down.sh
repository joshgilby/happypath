#!/bin/sh
# Stop the whole system, in the reverse order.
#
# The services go first. Destroying the lab while containers are still attached to its
# network leaves containerlab unable to remove that network.
set -e
cd "$(dirname "$0")"

echo "==> the services"
docker compose down

echo "==> the lab (containerlab; needs sudo)"
./lab/down.sh

echo
echo "Down. Your vault file is still here; nothing else of the system is."
