# quelaag

Tool to maintain secrets on network devices.

Quelaag watches the secrets configured on network devices and puts the known-good
value back when one changes — automatically, with no human in the loop. It is built
as a set of small cooperating services and doubles as an article series about
microservice architecture in network automation.

- **Get started**: [lab/README.md](lab/README.md) — run the two-device lab on your
  laptop, then see below to start everything at once
- **Verification**: [verification/README.md](verification/README.md) — what a `$8$`
  secret is, the library that reads and writes them, the encrypted vault holding the
  secrets they are checked against, and the service that answers whether a device's
  hash is the right one
- **Assurance**: [assurance/README.md](assurance/README.md) — the engine that reads a
  device, asks that question of every secret it finds, and puts back the ones that are
  wrong
- **Receiver**: [receiver/README.md](receiver/README.md) — how a device's own report of
  a change becomes an assurance run, and why this component is a configuration file
  rather than a program
- **The design**: [docs/design.md](docs/design.md) — the whole system on one page
- **The plan**: [docs/roadmap.md](docs/roadmap.md) — milestones, one article each

## Running the whole system

You supply one thing before anything runs: the credentials, in a `.env` file that is never
committed. [.env.example](.env.example) holds the lab's documented fakes and is the record
of what is needed — copy it and edit only if you changed them.

```sh
cp .env.example .env
./up.sh        # the lab, then the three services
./down.sh      # the services, then the lab
```

Both print each step as they run. A convenience that hides what it did leaves you unable
to work out which half broke, and there are two halves here: containerlab runs the
devices, Docker Compose runs the services, and neither can manage the other.

**The order is the whole reason these scripts exist.** The services attach to the network
containerlab creates, so the lab must come up first — start compose on its own and it
stops with `network quelaag-mgmt declared as external, but could not be found`, which is
that mistake, said plainly. Going down, the order reverses for the mirror-image reason:
destroy the lab while the services are still attached and containerlab cannot remove the
network it made.

Your secrets live in `~/.quelaag/vault.json`, which is yours and stays behind when the
system stops. It is the same file [the vault command line](verification/README.md) has
always used, so every command from earlier milestones keeps working against the running
system.
