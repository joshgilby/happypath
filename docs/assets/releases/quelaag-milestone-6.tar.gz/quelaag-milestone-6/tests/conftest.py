"""Stand-ins for the two things the engine talks to, and for a run in progress.

The engine's safety properties are claims about what it *asked a device to do*, so the
device double records every request rather than merely answering it. Without that,
"changed nothing else" and "refused an over-broad change" could not be tested at all.

Scheduling adds a second kind of claim — about what happens *while* a run is going on.
That is a state a test must create deliberately, never one it waits and hopes for.
"""

import threading
import time

import pytest

from assurance.devices import DeviceUnreachable

ADMIN_HASH = "$8$6MDQWLA4JAG.pU$2NYhnsjdrF.A2jgvUlpYU9DYJvSHgxAND7unfHGB7WY"
OPERATOR_HASH = "$8$sFgC4EoYt8zLlk$.Wizu/YErNa7KZUxBsytkw0mudxreuVse/bZY6oaLec"


class FakeDevice:
    """A device that answers as told and remembers everything it was asked."""

    def __init__(self):
        self.name = "test-device"
        self.users = {
            "admin": {"level": 15, "password": ADMIN_HASH},
            "operator": {"level": 1, "password": OPERATOR_HASH},
        }
        # What the device would say a staged change does. Tests override this to
        # rehearse a device that would change more than the engine intended.
        self.diff_for = lambda config: "\n".join(f"+{line}" for line in config)

        self.staged = []
        self.commits = 0
        self.readable = True

    def get_users(self):
        if not self.readable:
            raise DeviceUnreachable("device unreachable")
        return self.users

    def stage(self, config):
        self.staged.append(config)

    def what_would_change(self):
        return self.diff_for(self.staged[-1])

    def commit(self):
        self.commits += 1
        for line in self.staged[-1]:
            _, username, _, _, secret = line.split()
            self.users[username]["password"] = secret


class FakeVerification:
    """The verification service, answering with whatever verdicts a test chooses."""

    def __init__(self):
        self.verdicts = {}
        self.reachable = True
        self.replacement = "$8$NEWSALTNEWSALT$aNewHashForTheKnownGoodSecretxxxxxxxxxxxxx"
        # Every format the engine named, so a test can check it asked about the format
        # it read off the hash rather than one this double assumed.
        self.formats_asked = []

    def verdict_for(self, username, secret_hash, secret_format):
        self.formats_asked.append(secret_format)
        if not self.reachable:
            return "not_checkable"
        # The real service answers about the hash it is given, not about the account.
        # A hash this service issued is by definition the right one.
        if secret_hash == self.replacement:
            return "correct"
        return self.verdicts.get(username, "correct")

    def replacement_for(self, username, secret_format):
        self.formats_asked.append(secret_format)
        if not self.reachable:
            return None
        return self.replacement


class ControllableRun:
    """A stand-in for an assurance run that the test decides when to finish.

    Scheduling is about overlap, so a test needs a run that is genuinely in progress
    while it makes its next request. Sleeping for a moment and hoping is how flaky
    tests are written; this blocks until the test says otherwise.
    """

    def __init__(self):
        self.started = threading.Event()
        self.may_finish = threading.Event()
        self.entered = 0
        self.concurrent = 0
        self.most_at_once = 0
        self.devices = []
        self.dry_runs = []
        self._lock = threading.Lock()

    def __call__(self, device, dry_run=False):
        with self._lock:
            self.entered += 1
            self.concurrent += 1
            self.most_at_once = max(self.most_at_once, self.concurrent)
            self.devices.append(device)
            self.dry_runs.append(dry_run)
        self.started.set()
        self.may_finish.wait(timeout=5)
        with self._lock:
            self.concurrent -= 1

    def wait_until_running(self):
        assert self.started.wait(timeout=5), "the run never started"

    def wait_for_entries(self, count, timeout=5):
        deadline = time.time() + timeout
        while time.time() < deadline:
            with self._lock:
                if self.entered >= count:
                    return
            time.sleep(0.01)
        raise AssertionError(f"only {self.entered} run(s) happened, expected {count}")

    def release(self):
        self.may_finish.set()


@pytest.fixture
def controllable_run():
    return ControllableRun()


@pytest.fixture
def device():
    return FakeDevice()


@pytest.fixture
def service():
    return FakeVerification()
