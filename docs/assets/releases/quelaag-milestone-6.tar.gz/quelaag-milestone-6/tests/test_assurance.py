import time

import pytest

from assurance.engine import apply_plan, assure, decide

FINDINGS = ["correct", "wrong", "unmanaged", "not_checkable"]


def actions(run):
    return {f["username"]: f["action"] for f in run["findings"]}


def test_reads_every_user_with_privilege_and_format(device, service):
    report = decide(device, service)

    found = {finding["username"]: finding for finding in report}
    assert set(found) == {"admin", "operator"}
    assert found["admin"]["privilege"] == 15
    assert found["operator"]["privilege"] == 1
    assert found["admin"]["format"] == "type8"


@pytest.mark.parametrize("verdict", FINDINGS)
def test_each_service_outcome_maps_to_one_finding(device, service, verdict):
    service.verdicts = {"admin": verdict}

    findings = {f["username"]: f["finding"] for f in decide(device, service)}

    assert findings["admin"] == verdict


def test_a_secret_of_unknown_format_is_not_checkable(device, service):
    device.users["admin"]["password"] = "$9$somethingElseEntirely"

    findings = {f["username"]: f["finding"] for f in decide(device, service)}

    assert findings["admin"] == "not_checkable"


def test_the_engine_asks_about_the_format_it_read_off_the_hash(device, service):
    """FR-002: the request names the format, and FR-025 is why the engine works it out.

    A format the engine determines and then throws away is a decorative parameter, and
    the service would be guessing on its behalf.
    """
    device.users["admin"]["password"] = "$9$somethingElseEntirely"

    decide(device, service)

    assert service.formats_asked == ["type8"], "only the secret it could classify"


@pytest.mark.parametrize("verdict", ["correct", "unmanaged", "not_checkable"])
def test_nothing_is_staged_unless_a_secret_is_wrong(device, service, verdict):
    """The most important assertion in the milestone: silence unless sure."""
    service.verdicts = {"admin": verdict, "operator": verdict}

    assure(device, service)

    assert device.staged == []
    assert device.commits == 0


def test_a_wrong_secret_stages_exactly_one_line_per_wrong_secret(device, service):
    service.verdicts = {"admin": "wrong"}

    assure(device, service)

    assert len(device.staged) == 1
    assert device.staged[0] == [f"username admin secret 8 {service.replacement}"]
    assert device.commits == 1


def test_several_wrong_secrets_are_one_change_not_several(device, service):
    service.verdicts = {"admin": "wrong", "operator": "wrong"}

    assure(device, service)

    assert len(device.staged) == 1, "corrections must be staged together"
    assert len(device.staged[0]) == 2, "both corrections in the one change"
    assert device.commits == 1, "one commit, so Milestone 6 sees one event"


def test_every_replacement_is_obtained_before_anything_is_staged(device, service):
    """FR-005: a failure to obtain one must not be discovered mid-change."""
    service.verdicts = {"admin": "wrong", "operator": "wrong"}
    asked = []
    original = service.replacement_for

    def replacement_for(username, secret_format):
        asked.append(list(device.staged))
        return original(username, secret_format)

    service.replacement_for = replacement_for
    assure(device, service)

    assert asked == [[], []], "nothing was staged while replacements were still being got"
    assert len(device.staged) == 1


def test_a_secret_with_no_replacement_is_not_reported_as_failed(device, service):
    """`failed` means applied, re-checked, still wrong. Nothing was applied here."""
    service.verdicts = {"admin": "wrong"}
    service.replacement_for = lambda username, secret_format: None

    run = assure(device, service)

    assert device.staged == [], "the device was never touched"
    assert device.commits == 0
    assert actions(run)["admin"] == "no_replacement"


def test_a_change_the_device_says_does_too_much_is_refused(device, service):
    service.verdicts = {"admin": "wrong"}
    device.diff_for = lambda config: "+username admin secret 8 x\n-username admin privilege 15"

    run = assure(device, service)

    assert device.commits == 0, "nothing committed"
    assert actions(run)["admin"] == "refused"


def test_a_refusal_refuses_the_whole_change(device, service):
    service.verdicts = {"admin": "wrong", "operator": "wrong"}
    device.diff_for = lambda config: "+something entirely unexpected"

    run = assure(device, service)

    assert actions(run)["admin"] == "refused"
    assert actions(run)["operator"] == "refused"
    assert device.commits == 0


def test_a_correction_is_confirmed_by_reading_the_device_again(device, service):
    service.verdicts = {"admin": "wrong"}

    run = assure(device, service)

    assert actions(run)["admin"] == "corrected"


def test_a_device_that_goes_away_after_the_commit_still_reports_what_it_changed(device, service):
    """FR-013: a run that altered something and then failed is never mistaken for one
    that did nothing."""
    service.verdicts = {"admin": "wrong"}
    committed = device.commit

    def commit_then_vanish():
        committed()
        device.readable = False

    device.commit = commit_then_vanish
    run = assure(device, service)

    assert device.commits == 1, "the change was committed"
    assert actions(run)["admin"] == "applied_unconfirmed"


def unremarkable(device, service):
    pass


def device_would_do_more(device, service):
    device.diff_for = lambda config: "+username admin secret 8 x\n-username admin privilege 15"


def service_goes_quiet_after_the_commit(device, service):
    answered = service.verdict_for

    def verdict_for(username, secret_hash, secret_format):
        if device.commits:
            return "not_checkable"
        return answered(username, secret_hash, secret_format)

    service.verdict_for = verdict_for


def commit_has_no_effect(device, service):
    device.commit = lambda: setattr(device, "commits", device.commits + 1)


@pytest.mark.parametrize(
    "arrange, expected",
    [
        (unremarkable, "corrected"),
        (device_would_do_more, "refused"),
        (service_goes_quiet_after_the_commit, "applied_unconfirmed"),
        (commit_has_no_effect, "failed"),
    ],
)
def test_the_four_correction_results_are_each_reached_and_never_collapsed(
    device, service, arrange, expected
):
    """Four situations, four results. A report that blurred unconfirmed into confirmed
    would be worse than one that omitted the distinction (FR-013)."""
    service.verdicts = {"admin": "wrong"}
    arrange(device, service)

    run = assure(device, service)

    assert actions(run)["admin"] == expected


def test_a_dry_run_commits_nothing(device, service):
    service.verdicts = {"admin": "wrong"}

    run = assure(device, service, dry_run=True)

    assert device.commits == 0
    assert actions(run)["admin"] == "would_correct"


def test_a_dry_run_reports_the_change_the_device_itself_would_make(device, service):
    """SC-012. A dry run that only reported the engine's intention would be reporting
    the one thing nobody needs checked."""
    service.verdicts = {"operator": "wrong"}
    before = device.users["operator"]["password"]

    run = assure(device, service, dry_run=True)

    assert run["change"] == f"+username operator secret 8 {service.replacement}"
    assert device.commits == 0
    assert device.users["operator"]["password"] == before


def test_a_dry_run_says_so_when_the_device_would_do_too_much(device, service):
    service.verdicts = {"admin": "wrong"}
    device.diff_for = lambda config: "+something entirely unexpected"

    run = assure(device, service, dry_run=True)

    assert actions(run)["admin"] == "would_refuse"
    assert device.commits == 0


def test_a_dry_run_plans_exactly_what_a_real_run_does(device, service):
    service.verdicts = {"admin": "wrong", "operator": "wrong"}

    planned = {f["username"] for f in assure(device, service, dry_run=True)["findings"]
               if f["action"] == "would_correct"}
    corrected = {f["username"] for f in assure(device, service)["findings"]
                 if f["action"] == "corrected"}

    assert planned == corrected


def test_a_second_run_changes_nothing(device, service):
    service.verdicts = {"admin": "wrong"}

    assure(device, service)
    service.verdicts = {}  # the correction took, so nothing is wrong now
    run = assure(device, service)

    assert device.commits == 1, "the second run committed nothing"
    assert all(action == "none" for action in actions(run).values())


def test_every_run_stages_once_and_leaves_the_same_thing_behind(device, service):
    """FR-026: the same location every time and the same leftovers, so an operator
    never has to work out which kind of run put a file there.

    Nothing is ever discarded, because on this platform discarding is itself a
    configuration change — see the note in assurance/devices.py.
    """
    service.verdicts = {"admin": "wrong"}

    assure(device, service, dry_run=True)
    refused = list(device.staged)
    assure(device, service)

    assert len(device.staged) == 2, "one staging per run, never one per secret"
    assert device.staged[0] == device.staged[1], "a dry run leaves what a real run leaves"
    assert refused == device.staged[:1]


def test_an_unreadable_device_is_reported_and_untouched(device, service):
    device.readable = False

    run = assure(device, service)

    assert device.staged == []
    assert run["read"] is False
    assert run["findings"] == []


def test_a_device_with_no_users_is_not_confused_with_one_that_cannot_be_read(device, service):
    """Two different outcomes: nothing to check is ordinary, not being able to look is
    not (spec Edge Cases)."""
    device.users = {}
    empty = assure(device, service)

    device.readable = False
    unreadable = assure(device, service)

    assert empty["read"] is True and empty["findings"] == []
    assert unreadable["read"] is False


def test_every_report_names_the_device_the_time_and_whether_it_was_a_dry_run(device, service):
    """FR-013, and FR-018's reason for it: a saved report must never be mistakeable
    later for evidence that changes were made."""
    for dry_run in (True, False):
        run = assure(device, service, dry_run=dry_run)

        assert run["device"] == "test-device"
        assert run["at"].endswith("+00:00")
        assert run["dry_run"] is dry_run


def test_the_service_answers_for_a_device_it_does_not_manage():
    """FR-028: refused before anything is scheduled, and said so at once."""
    from assurance.service import AssureRequest, assure_device

    answer = assure_device(AssureRequest(device="not-in-the-inventory"))

    assert answer["accepted"] == "unknown"


def test_the_service_answers_with_what_became_of_the_request_not_what_was_found():
    """FR-023, FR-028. The reply is an acknowledgement; findings go to the engine's own
    output, because a queued or absorbed run has no caller left to return them to."""
    from assurance.service import AssureRequest, assure_device

    answer = assure_device(AssureRequest(device="not-in-the-inventory"))

    assert set(answer) == {"device", "accepted"}
    assert "findings" not in answer


def test_a_run_with_no_caller_still_renders_its_findings(device, service, capsys):
    """FR-023. Nobody is waiting for a scheduled run, so a report that went only to a
    caller would go nowhere at all."""
    from assurance.engine import render

    render(assure(device, service))

    printed = capsys.readouterr().out
    assert "admin" in printed and "correct" in printed


def test_the_service_defaults_to_correcting_not_dry_running():
    from assurance.service import AssureRequest

    assert AssureRequest(device="r1").dry_run is False


def test_apply_plan_is_separate_from_deciding(device, service):
    """FR-019: one decision step, which a normal run acts on and a dry run reports."""
    service.verdicts = {"admin": "wrong"}

    findings = decide(device, service)
    assert device.staged == [], "deciding touches nothing"

    apply_plan(device, service, findings)
    assert device.commits == 1


def test_the_scheduler_answers_at_once_while_a_run_is_in_progress(controllable_run):
    """FR-028: the caller is told what became of its request, not made to wait. Proven
    by the run still being held open when the second answer comes back."""
    from assurance.scheduler import Scheduler

    scheduler = Scheduler(controllable_run)

    assert scheduler.request("r1") == "started"
    controllable_run.wait_until_running()
    assert scheduler.request("r1") == "queued", "answered while the first run is still going"

    controllable_run.release()


def test_any_number_of_requests_during_one_run_become_exactly_one_more(controllable_run):
    """FR-029, FR-030, SC-020. A flag, not a queue — five requests owe one run."""
    from assurance.scheduler import Scheduler

    scheduler = Scheduler(controllable_run)
    scheduler.request("r1")
    controllable_run.wait_until_running()

    answers = [scheduler.request("r1") for _ in range(5)]

    assert answers == ["queued", "absorbed", "absorbed", "absorbed", "absorbed"]
    controllable_run.release()
    controllable_run.wait_for_entries(2)
    assert controllable_run.entered == 2, "five requests, one further run — never five"


def test_two_runs_for_one_device_never_overlap(controllable_run):
    """FR-029. Two runs against one device would each act on a configuration the other
    is changing."""
    from assurance.scheduler import Scheduler

    scheduler = Scheduler(controllable_run)
    scheduler.request("r1")
    controllable_run.wait_until_running()
    scheduler.request("r1")
    controllable_run.release()
    controllable_run.wait_for_entries(2)

    assert controllable_run.most_at_once == 1


def test_different_devices_are_assured_independently(controllable_run):
    """FR-029: one device's run must not hold up another's."""
    from assurance.scheduler import Scheduler

    scheduler = Scheduler(controllable_run)

    assert scheduler.request("r1") == "started"
    controllable_run.wait_until_running()
    assert scheduler.request("r2") == "started", "r2 is not queued behind r1"

    controllable_run.release()
    controllable_run.wait_for_entries(2)
    assert sorted(controllable_run.devices) == ["r1", "r2"]


def test_a_request_arriving_as_a_run_ends_is_not_dropped():
    """FR-030. Deciding a run is finished and letting go of the device have to happen
    under one hold of the lock; apart, a request landing in between marks a run pending
    that nobody performs — a change lost to a race."""
    from assurance.scheduler import Scheduler

    runs = []

    def run_and_be_interrupted(device, dry_run=False):
        runs.append(device)
        if len(runs) == 1:
            # a request arriving while this very run is in progress
            assert scheduler.request(device) == "queued"

    scheduler = Scheduler(run_and_be_interrupted)
    scheduler.request("r1")

    deadline = time.time() + 5
    while len(runs) < 2 and time.time() < deadline:
        time.sleep(0.01)

    assert runs == ["r1", "r1"], "the queued run must actually happen"


def test_the_scheduler_forgets_a_device_once_it_is_idle(controllable_run):
    """Nothing may be left marked busy: a device stuck in that state would never be
    assured again, and the silence would look exactly like having nothing to do."""
    from assurance.scheduler import Scheduler

    scheduler = Scheduler(controllable_run)
    scheduler.request("r1")
    controllable_run.wait_until_running()
    controllable_run.release()
    controllable_run.wait_for_entries(1)

    deadline = time.time() + 5
    while scheduler.running and time.time() < deadline:
        time.sleep(0.01)

    assert scheduler.running == set() and scheduler.pending == {}


def test_a_real_request_absorbed_into_a_pending_dry_run_makes_it_real(controllable_run):
    """FR-030: coalescing may never lose a change. A dry run satisfies a request to
    look, but not a request to put right, so the owed run takes the stronger of the two."""
    from assurance.scheduler import Scheduler

    scheduler = Scheduler(controllable_run)
    scheduler.request("r1")
    controllable_run.wait_until_running()

    assert scheduler.request("r1", dry_run=True) == "queued"
    assert scheduler.request("r1", dry_run=False) == "absorbed"

    controllable_run.release()
    controllable_run.wait_for_entries(2)
    assert controllable_run.dry_runs[1] is False, "the correction asked for still happens"


def test_a_device_can_be_named_by_the_address_a_message_came_from():
    """FR-010: a syslog daemon knows 192.0.2.11 and has never heard of r1."""
    from assurance.devices import device_named

    assert device_named("192.0.2.11") == "r1"
    assert device_named("r1") == "r1", "a name still works, e.g. for a person with curl"


def test_an_address_the_inventory_does_not_know_is_refused():
    """FR-015, SC-005. This is also how a botched deployment announces itself: behind
    address translation every message arrives bearing a gateway address, which is not a
    managed device, so everything is refused rather than silently misattributed."""
    from assurance.devices import device_named

    assert device_named("203.0.113.99") is None
    assert device_named("192.0.2.1") is None, "the gateway is not a managed device"


def test_a_failed_correction_is_not_attempted_again_while_nothing_has_changed(device, service):
    """FR-016a. A correction that commits and then fails to verify is itself a
    configuration change, so it provokes the run that would try it again. Without this
    the system rewrites a device forever — the runaway FR-016 is named for."""
    from assurance.engine import StandingOff

    service.verdicts = {"admin": "wrong"}
    device.commit = lambda: setattr(device, "commits", device.commits + 1)  # no effect
    standing_off = StandingOff()

    first = assure(device, service, standing_off=standing_off)
    assert actions(first)["admin"] == "failed"

    second = assure(device, service, standing_off=standing_off)

    assert actions(second)["admin"] == "not_reattempted"
    assert len(device.staged) == 1, "the second run staged nothing at all"
    assert device.commits == 1


def test_standing_off_lifts_by_itself_once_the_value_differs(device, service):
    """FR-016b. Nothing may need resetting by hand: a system that must be told it may
    resume is a system that stays switched off by accident."""
    from assurance.engine import StandingOff

    service.verdicts = {"admin": "wrong"}
    device.commit = lambda: setattr(device, "commits", device.commits + 1)
    standing_off = StandingOff()

    assure(device, service, standing_off=standing_off)
    assert actions(assure(device, service, standing_off=standing_off))["admin"] == "not_reattempted"

    device.users["admin"]["password"] = "$8$SomebodyElseChangedIt$xxxxxxxxxxxxxxxxxxxxxx"
    third = assure(device, service, standing_off=standing_off)

    assert actions(third)["admin"] != "not_reattempted", "the reason for standing off has gone"
    assert device.commits == 2


def test_a_correction_that_works_leaves_nothing_standing_off(device, service):
    """A device that was fixed must not be remembered as unfixable."""
    from assurance.engine import StandingOff

    service.verdicts = {"admin": "wrong"}
    standing_off = StandingOff()

    assert actions(assure(device, service, standing_off=standing_off))["admin"] == "corrected"
    assert standing_off.unchanged_since == {}

    # drift it again, by hand as a person would
    device.users["admin"]["password"] = "$8$DriftedAgainByHand$xxxxxxxxxxxxxxxxxxxxxxxx"
    service.verdicts = {"admin": "wrong"}

    assert actions(assure(device, service, standing_off=standing_off))["admin"] == "corrected"


def test_standing_off_is_per_secret_not_per_device(device, service):
    """One secret the engine cannot fix must not suspend the others on that device."""
    from assurance.engine import StandingOff

    service.verdicts = {"admin": "wrong"}
    device.commit = lambda: setattr(device, "commits", device.commits + 1)
    standing_off = StandingOff()
    assure(device, service, standing_off=standing_off)

    del device.commit  # the real one commits again from here
    service.verdicts = {"admin": "wrong", "operator": "wrong"}
    run = assure(device, service, standing_off=standing_off)

    assert actions(run)["admin"] == "not_reattempted"
    assert actions(run)["operator"] == "corrected", "the other secret is still maintained"


def test_a_dry_run_asked_for_over_the_service_is_a_dry_run(controllable_run, monkeypatch):
    """The field was declared on the request and then dropped: the scheduler took a
    device name and nothing else, so a caller that asked the engine to *look* had its
    device corrected instead. The opposite of what was asked, and silently."""
    import assurance.service as service_module
    from assurance.scheduler import Scheduler

    monkeypatch.setattr(service_module, "scheduler", Scheduler(controllable_run))
    service_module.assure_device(service_module.AssureRequest(device="r1", dry_run=True))
    controllable_run.wait_until_running()
    controllable_run.release()
    controllable_run.wait_for_entries(1)

    assert controllable_run.dry_runs == [True]


def test_a_refused_request_says_so_on_the_engines_own_output(capsys):
    """FR-015. The refusal used to live only in the HTTP response, and the only caller
    is a syslog daemon that forwards and forgets — so a system refusing everything
    looked exactly like a system with nothing to do."""
    from assurance.service import AssureRequest, assure_device

    assure_device(AssureRequest(address="203.0.113.99"))

    assert "203.0.113.99" in capsys.readouterr().out
