# The Syslog Receiver

This is the part of quelaag that notices. Devices report changes to their own user table;
the receiver forwards each one to the assurance engine, which decides what to do about it.

**It is not a program.** It is the stock `rsyslog/rsyslog:2026-04` image and the twelve
lines of configuration in [quelaag.conf](quelaag.conf). Everything it needs to do — listen
on a port, keep the messages worth keeping, forward them — an ordinary syslog daemon has
done for decades. The smallest component in a system is the one nobody had to build.

```sh
./up.sh                          # it comes up with everything else
docker logs quelaag-receiver-1   # what it has been doing
```

## What it forwards

One thing: a device saying `USER TABLE MODIFIED` — its own marker for *the local user
table just changed*. Everything else is dropped, and so is anything it cannot make sense
of.

**Not `%SYS-5-CONFIG_I`**, which is the obvious choice and the wrong one. That message is
emitted when someone *leaves* configuration mode, so the delay before quelaag notices
belongs to whoever made the change — change a secret, stay in configuration mode, and the
system never hears about it at all. Measured: with a session holding configuration mode
open, the marker had already been logged and `CONFIG_I` had not appeared. A detection time
an adversary chooses is not a detection time.

The devices are *also* configured to send only the marker, and here that is doing security
work rather than noise reduction. The same logging feature emits a second message
recording the command that was applied — `username operator … secret <hash>` — and that is
the one line in this system carrying a credential. Filtering on the marker at the device
*and* at the receiver means it never leaves the device by either path.

There is a redaction keyword, `hidekeys`, which replaces that hash with `*`. It is
deliberately not what this rests on: it was set during this work and then found simply
absent from the running configuration, no error, no warning. A design that leaks
credentials when one keyword fails to apply is a design that leaks credentials.

## Which device a message is about

**Where it came from, never what it says.**

Syslog is unauthenticated. Anything that can reach the port can send a message claiming to
be any device it likes, so the text is worth nothing as identification. The source address
of the datagram is at least the address the packet arrived from, so that is what gets sent
to the engine — which resolves it against the inventory it already keeps.

Getting the *kind* of message wrong is cheap: a run happens, finds everything correct, and
changes nothing. Getting the *device* wrong would act on the wrong machine. Only one of the
two has to be trustworthy, and it is the one the receiver does not read.

## What this depends on, and how it breaks

The receiver sits on the lab's own network at a fixed address. That is not a deployment
preference — it is the thing device identification rests on.

Behind address translation, every message arrives bearing the gateway's address. Measured
with the same configuration:

| Deployment | Address the receiver saw |
|------------|--------------------------|
| bridge networking with a published port | `172.17.0.1` — the Docker gateway |
| on the lab's network | `192.0.2.11` — r1's own address |

The system does say so rather than acting on it: a gateway address belongs to no managed
device, so the engine refuses every request as `unknown` and reports why. But nothing in
the *configuration* would look wrong, which is why the compose file fixes the network and
why this is checked against a real device rather than a synthetic sender.

## Why the system does not chase its own tail

A correction changes the user table too, so the device reports it, so it arrives here and
gets forwarded like any other. The receiver does nothing clever about that — it has no
memory and makes no judgements at all.

The engine settles it instead: one run per device at a time, and **at most one further run
owed**. Any number of messages arriving during a run collapse into that single one, so the
sequence always terminates. A run that finds everything correct changes nothing and
therefore provokes nothing.

That is also why the receiver may be careless where the engine may not. If rsyslog decides
to redeliver a message it thinks failed, no harm is done: the repeat is absorbed.

## What it cannot do

It never reads the vault, never verifies or generates a hash, and never touches a device.
Those are not rules it follows — there is no code of ours in it to break them with.

It does not authenticate anything, and neither does the engine it calls. The exposure that
creates is bounded and worth stating: the worst a forged message achieves is an assurance
run, and a run may only replace a secret the verification service has called *wrong*.

## One thing to expect when wiring a running device

Adding `logging host` to a device that is already up does not take effect for the very
next change — observed on both lab devices, twice each. The change after that one arrives
normally.

It does not come up in ordinary use, because the devices boot with the logging already in
their baseline configuration. It only bites when you add it by hand to a running device and
then wonder why nothing happened.

## What a lost message costs

Syslog offers no delivery guarantee. A message that goes missing means a drift that goes
uncorrected until something else provokes a run — the same as if the receiver were down.

This system reacts to changes it hears about. It is not a promise that every device is
always correct, and it should not be read as one. Scheduled sweeps across the whole fleet,
which would close that gap, are on the [roadmap backlog](../docs/roadmap.md).

## Replacing it

Anything that can send the engine a device's address will do — the engine has no idea what
is calling it, and nothing here is special to rsyslog:

```http
POST /assure
{ "address": "192.0.2.11" }
```

## Four details that must be right

Each of these failed silently at least once while this was being worked out:

| Detail | What happens without it |
|--------|-------------------------|
| On the lab's network, not a published port | Every device arrives as the gateway |
| `usehttps="off"` | `omhttp` defaults to HTTPS, fails with an OpenSSL error, and suspends itself |
| Filter on `$msg`, not `$syslogtag` | A Cisco message's tag is its *sequence number*, so the filter matches nothing |
| Port 5514, not 514 | The image runs unprivileged and cannot bind a privileged port |
