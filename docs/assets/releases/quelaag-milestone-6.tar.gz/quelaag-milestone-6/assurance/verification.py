"""Asking the verification service.

Every judgement the engine acts on comes from here. The one rule this module exists to
enforce: not being able to reach the service is never evidence that a secret is wrong.
"""

import json
import os
import urllib.error
import urllib.request

SERVICE = os.environ.get("QUELAAG_SERVICE_URL", "http://localhost:8474")

VERDICTS = {"valid": "correct", "invalid": "wrong", "unknown": "unmanaged"}


def ask(path, body):
    request = urllib.request.Request(
        f"{SERVICE}{path}",
        data=json.dumps(body).encode(),
        headers={"content-type": "application/json"},
    )
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            return json.load(response)
    except (urllib.error.URLError, OSError):
        return None


class Verification:
    def __init__(self, service):
        self.service = service

    def verdict_for(self, username, secret_hash, secret_format):
        # The format is the one the engine read off the hash itself, not an assumption
        # made here: this module knows how to ask, not what a device holds.
        answer = ask(
            "/verify",
            {
                "service": self.service,
                "username": username,
                "format": secret_format,
                "hash": secret_hash,
            },
        )
        if answer is None or "verdict" not in answer:
            return "not_checkable"
        return VERDICTS.get(answer["verdict"], "not_checkable")

    def replacement_for(self, username, secret_format):
        answer = ask(
            "/replacement",
            {"service": self.service, "username": username, "format": secret_format},
        )
        if answer is None:
            return None
        return answer.get("hash")
