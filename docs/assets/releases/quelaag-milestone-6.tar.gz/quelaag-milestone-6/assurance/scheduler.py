"""Deciding when a run happens, now that something other than a person asks.

A person asks once and waits. A program asks whenever it has reason to, which may be
twice in a second and while a run is already going — so the engine has to be safe to call
repeatedly and at any moment. Two rules do that: one run per device at a time, and at most
one further run owed. Any number of requests arriving during a run collapse into that
single one.

The first rule is the one with teeth. Two overlapping runs against a device would each
read a configuration the other is changing, and each decide from what it read. The second
rule is what makes a repeated request cost nothing, which is worth having before anything
starts repeating them.
"""

import threading


class Scheduler:
    """Which devices are being assured, and which are owed one more run."""

    def __init__(self, run):
        self.run = run
        self.running = set()
        # Device to the kind of run it is owed. A device appears at most once, which is
        # the whole point; the value says whether that owed run may skip the correcting.
        self.pending = {}
        self.lock = threading.Lock()

    def request(self, device, dry_run=False):
        """Say what became of the request, at once. The run happens on our own time."""
        with self.lock:
            if device in self.running:
                if device in self.pending:
                    # A pending run is a dry run only if every request folded into it
                    # was one. Absorbing a real request into a dry run would lose the
                    # correction it asked for, and coalescing may never lose a change.
                    self.pending[device] = self.pending[device] and dry_run
                    return "absorbed"
                self.pending[device] = dry_run
                return "queued"
            self.running.add(device)

        threading.Thread(target=self.work, args=(device, dry_run), daemon=True).start()
        return "started"

    def work(self, device, dry_run):
        try:
            while True:
                self.run(device, dry_run)
                with self.lock:
                    if device not in self.pending:
                        # Deciding we are finished and letting go of the device must
                        # happen under one hold of the lock. Apart, a request arriving
                        # in between would mark a run pending that nobody would ever
                        # perform — a change quietly dropped.
                        self.running.discard(device)
                        return
                    dry_run = self.pending.pop(device)
        except BaseException:
            # However this failed, the device is idle again. Left marked busy it would
            # never be assured again: a silence indistinguishable from having nothing
            # to do.
            with self.lock:
                self.running.discard(device)
                self.pending.pop(device, None)
            raise
