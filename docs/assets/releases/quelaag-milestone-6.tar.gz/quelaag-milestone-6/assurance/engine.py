"""Works out what is wrong with a device's secrets, and puts them right.

Deciding and applying are separate on purpose. A dry run and a normal run both decide,
and both then build the change and ask the device what it would do; only a normal run
commits it. Because there is one place conclusions are reached and one place the change
is built, a dry run cannot tell you one thing and a real run do another.
"""

import sys
from datetime import datetime, timezone

from assurance.devices import DeviceUnreachable

FORMAT_PREFIXES = {"$8$": "type8"}


class StandingOff:
    """Corrections already applied and seen to fail, and the hash each one wrote.

    A failed correction is itself a configuration change, so it provokes the run that
    would attempt it again — and that run fails the same way. Remembering what was
    written, and declining while the device still holds it, is what stops that becoming
    a loop.

    What is remembered is the value the device *held* when the correction failed. It
    clears itself: once the device holds something else, something has changed and the
    reason for standing off has gone with it, so the engine simply tries again. Nothing
    has to be reset by hand.
    """

    def __init__(self):
        self.unchanged_since = {}

    def is_standing_off(self, device_name, finding):
        return self.unchanged_since.get((device_name, finding["username"])) == finding["hash"]

    def note(self, device_name, finding):
        if finding["action"] == "failed":
            # What the device *holds*, not what we wrote — those differ whenever the
            # commit did not take, which is the likeliest way a correction fails.
            # Remembering what we wrote would leave the loop wide open in exactly the
            # case this exists to close.
            self.unchanged_since[(device_name, finding["username"])] = finding["observed"]
        else:
            self.unchanged_since.pop((device_name, finding["username"]), None)


def format_of(secret):
    for prefix, name in FORMAT_PREFIXES.items():
        if secret.startswith(prefix):
            return name
    return None


def decide(device, service):
    """Read the device, ask about every secret, and conclude. Touches nothing."""
    findings = []
    for username, user in sorted(device.get_users().items()):
        secret_format = format_of(user["password"])
        finding = (
            service.verdict_for(username, user["password"], secret_format)
            if secret_format
            else "not_checkable"  # cannot be asked about, so nothing may be concluded
        )
        findings.append(
            {
                "username": username,
                "privilege": user["level"],
                "format": secret_format,
                "hash": user["password"],
                "finding": finding,
                "action": "none",
            }
        )
    return findings


def propose(device, service, corrections):
    """Build the one change this run would make and get the device's account of it.

    Nothing is committed here, so a dry run and a normal run arrive at this same point
    by the same route and are told the same thing.
    """
    for finding in corrections:
        finding["replacement"] = service.replacement_for(
            finding["username"], finding["format"]
        )
    # Every replacement first: a failure to obtain one must not leave a device
    # half-changed, so we find out before the device is touched at all.
    if any(f["replacement"] is None for f in corrections):
        return None

    device.stage([f"username {f['username']} secret 8 {f['replacement']}" for f in corrections])
    return device.what_would_change()


def apply_plan(device, service, findings, standing_off=None):
    """Correct every secret found wrong, as one change to the device."""
    standing_off = standing_off or StandingOff()
    wrong = [f for f in findings if f["finding"] == "wrong"]

    declined = [f for f in wrong if standing_off.is_standing_off(device.name, f)]
    set_action(declined, "not_reattempted")

    corrections = [f for f in wrong if f not in declined]
    if not corrections:
        return None

    account = propose(device, service, corrections)
    if account is None:
        set_action(corrections, "no_replacement")
        return None

    # A device that would change anything else — drop a privilege, touch a neighbouring
    # line — is refused here rather than discovered afterwards.
    if not describes_only(account, corrections):
        set_action(corrections, "refused")
        return account

    device.commit()
    try:
        confirm(device, service, corrections)
    except DeviceUnreachable:
        # The change was committed; we simply cannot say yet whether it took.
        set_action(corrections, "applied_unconfirmed")

    for finding in corrections:
        standing_off.note(device.name, finding)
    return account


def plan_only(device, service, findings):
    """A dry run: build the change and ask the device what it would do, but never
    commit it.

    What gets reported is what the device said, not what the engine intended — which is
    the whole reason a dry run is worth consulting.
    """
    corrections = [f for f in findings if f["finding"] == "wrong"]
    if not corrections:
        return None

    account = propose(device, service, corrections)
    if account is None:
        set_action(corrections, "no_replacement")
        return None

    would = "would_correct" if describes_only(account, corrections) else "would_refuse"
    set_action(corrections, would)
    return account


def confirm(device, service, corrections):
    """Read each corrected secret back and ask again — per secret, because one secret
    failing to verify says nothing about the others in the same change."""
    users = device.get_users()
    for finding in corrections:
        current = users[finding["username"]]["password"]
        finding["observed"] = current
        verdict = service.verdict_for(finding["username"], current, finding["format"])
        finding["action"] = {
            "correct": "corrected",
            "not_checkable": "applied_unconfirmed",
        }.get(verdict, "failed")


def set_action(findings, action):
    for finding in findings:
        finding["action"] = action


def describes_only(account, corrections):
    """Does the device's account of a change mention nothing but these secrets?"""
    expected = {f"username {f['username']} secret 8 {f['replacement']}" for f in corrections}
    for line in account.splitlines():
        if line.lstrip("+-").strip() not in expected:
            return False
    return True


def report(device_name, dry_run, findings, change=None, read=True):
    """The only thing that leaves the engine, built in one place so that the command
    line and the service can never describe the same run differently."""
    return {
        "device": device_name,
        "at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "dry_run": dry_run,
        "read": read,
        "findings": findings,
        "change": change,
    }


def render(run):
    """Print a run the way an operator reads it.

    One renderer, because there are now two callers: a person at a command line, and a
    service printing runs nobody is waiting for (FR-014). Two renderings of one report
    would drift apart, which is the argument FR-019 already makes about dry runs.

    It flushes. A terminal flushes each line on its own, but output redirected to a file
    or collected from a container is block-buffered, so a run's findings would sit
    invisible until enough of them accumulated to fill the buffer. Findings an operator
    cannot see yet are not reported.
    """
    print(f"{run['device']} at {run['at']}{' (dry run)' if run['dry_run'] else ''}")

    if not run["read"]:
        print("  could not inspect this device")
    elif not run["findings"]:
        print("  no local-user secrets to check")
    else:
        for finding in run["findings"]:
            print(
                f"  {finding['username']} (privilege {finding['privilege']}):"
                f" {finding['finding']} — {finding['action']}"
            )

        # The device's own account of the change, rather than the engine's intention.
        if run["change"]:
            print("  the device says this change would do:")
            for line in run["change"].splitlines():
                print(f"    {line}")

    sys.stdout.flush()


def render_unmanaged(name):
    """Say, on the engine's own output, that a request named nothing we manage.

    FR-014's argument applies here too, and was missed: the answer to a request goes to
    a caller, and the caller is a syslog daemon that forwards and forgets. Returned in
    the response alone, a refusal reached nobody — the engine's log showed a plain
    `200 OK`, indistinguishable from a request it had acted on.

    That is the observation FR-015 exists to make possible. It is also how the one
    deployment mistake that breaks everything announces itself: put address translation
    in the path and every device arrives wearing the gateway's address, which belongs to
    no managed device, so *nothing* is ever assured. Loud, but only if it is said aloud.
    """
    print(f"{name} is not a device this engine manages — nothing done")
    sys.stdout.flush()


def assure(device, service, dry_run=False, standing_off=None):
    """One run: read, decide, and — unless this is a dry run — put right what is wrong."""
    try:
        findings = decide(device, service)
    except DeviceUnreachable:
        # We could not look, so we know nothing and we change nothing.
        return report(device.name, dry_run, [], read=False)

    change = (
        plan_only(device, service, findings)
        if dry_run
        else apply_plan(device, service, findings, standing_off)
    )
    return report(device.name, dry_run, findings, change)
