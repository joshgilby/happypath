"""Check a device, and put right what is wrong.

    QUELAAG_DEVICE_USER=admin QUELAAG_DEVICE_PASSWORD=... \\
        uv run python -m assurance.cli r1 [--dry-run]

Credentials come from the environment. --dry-run reports what would be corrected and
changes nothing.
"""

import sys

from assurance.devices import DeviceUnreachable, open_device
from assurance.engine import assure, render, render_unmanaged, report
from assurance.verification import Verification


def main():
    name = sys.argv[1]
    dry_run = "--dry-run" in sys.argv

    try:
        device = open_device(name)
    except DeviceUnreachable:
        render(report(name, dry_run, [], read=False))
        return

    if device is None:
        render_unmanaged(name)
        return

    run = assure(device, Verification(name), dry_run=dry_run)
    device.close()
    render(run)


if __name__ == "__main__":
    main()
