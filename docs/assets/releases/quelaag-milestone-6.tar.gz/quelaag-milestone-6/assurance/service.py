"""The assurance engine, reachable by another program.

    QUELAAG_DEVICE_USER=admin QUELAAG_DEVICE_PASSWORD=... \\
        uv run uvicorn assurance.service:app --host localhost --port 8475

A syslog receiver names a device here whenever that device reports a configuration
change. It knows the address the message came from and has never heard of `r1`, so both
work. It is answered at once and never made to wait for the run: a caller held open for
as long as a device takes to answer would back up whatever is calling.

Because a queued run has nobody waiting for it, findings are printed here rather than
returned. Callers are not authenticated, which is why nothing binds beyond localhost and
the lab's own network.
"""

from fastapi import FastAPI
from pydantic import BaseModel

from assurance.devices import DeviceUnreachable, device_named, open_device
from assurance.engine import StandingOff, assure, render, render_unmanaged, report
from assurance.scheduler import Scheduler
from assurance.verification import Verification

app = FastAPI()

# What the engine is standing off from, across every run this process performs. It has
# to outlive a single run: that is the whole point of remembering a correction that
# failed.
standing_off = StandingOff()


def run_assurance(device_name, dry_run=False):
    try:
        device = open_device(device_name)
    except DeviceUnreachable:
        render(report(device_name, dry_run, [], read=False))
        return

    findings = assure(device, Verification(device_name), dry_run=dry_run,
                      standing_off=standing_off)
    device.close()
    render(findings)


scheduler = Scheduler(run_assurance)


class AssureRequest(BaseModel):
    device: str | None = None
    address: str | None = None
    dry_run: bool = False


@app.post("/assure")
def assure_device(request: AssureRequest):
    """Say what became of the request. The run happens on the engine's own time."""
    asked_about = request.address or request.device
    device_name = device_named(asked_about or "")
    if device_name is None:
        render_unmanaged(asked_about)
        return {"device": asked_about, "accepted": "unknown"}

    return {
        "device": device_name,
        "accepted": scheduler.request(device_name, request.dry_run),
    }
