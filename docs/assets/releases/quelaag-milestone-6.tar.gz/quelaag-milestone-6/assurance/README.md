# The Assurance Engine

This is the part of quelaag that touches devices. It reads a device's local-user
secrets, asks the verification service about each one, and puts back the ones that are
wrong.

```sh
export QUELAAG_DEVICE_USER=admin
export QUELAAG_DEVICE_PASSWORD='your-device-password'

uv run python -m assurance.cli r1            # check, and correct what is wrong
uv run python -m assurance.cli r1 --dry-run  # say what would be corrected, change nothing
```

```text
r1 at 2026-08-05T17:31:04+00:00
  admin (privilege 15): correct — none
  backup (privilege 1): wrong — corrected
  operator (privilege 1): correct — none
  the device says this change would do:
    +username backup secret 8 $8$pbJntvj7GJGdXp$KWzCCovwx4wSMx2bcxoDIkDy7xYusz/4.axhf1iiqak
```

Or as a service, which is how Milestone 6 will reach it:

```sh
uv run uvicorn assurance.service:app --host localhost --port 8475

curl -X POST localhost:8475/assure -H 'content-type: application/json' \
  -d '{"device": "r1", "dry_run": true}'
```

## What it will and will not change

It changes a secret **only** when the verification service says that secret is wrong.
There are four things it can conclude, and only one of them permits touching anything:

| Finding | What it means | What the engine does |
|---------|---------------|----------------------|
| correct | the device's secret matches the vault | nothing |
| **wrong** | it does not match | **corrects it** |
| unmanaged | the vault has no secret for that account | nothing |
| not checkable | the service could not answer, or the secret is in a format the engine cannot identify | nothing |

The last row is the one worth dwelling on. **Not being able to check is never evidence
that something is wrong.** If the verification service is down, every secret comes back
not checkable and the engine touches nothing at all — which is the correct behaviour,
and the opposite of what a system that assumed the worst would do.

It never handles a plaintext secret. When a correction is needed it asks the
verification service for a ready-made hash, so the thing that talks to your devices is
never the thing that knows your passwords.

## How a correction happens

1. The replacement hashes are fetched **first**, so a failure to get one cannot leave a
   device half-changed.
2. All of the corrections are staged as **one** change, however many secrets are wrong.
3. The device is asked what that change would do. **If it reports anything beyond
   replacing those secrets — dropping a privilege, touching a neighbouring line — the
   change is refused and nothing is applied.** The engine does not trust its own belief
   that it is only changing one thing; it checks.
4. Only then is the change committed, and it survives a reboot.
5. Each corrected secret is read back from the device and re-checked. A correction is
   reported as confirmed only if that check passes.

It makes **one attempt**. A secret that does not come right is reported as failed, not
retried — the next run will find it again, which is the system working rather than a
reason to loop.

The report never blurs these together. `corrected` means applied and re-checked;
`applied_unconfirmed` means applied but the check could not be made; `refused` means
nothing was applied because the device said the change would do too much; `failed` means
applied and still wrong; and `no_replacement` means the service called a secret wrong but
could not supply a right one, so the device was never touched at all.

If a device disappears partway, the report still tells you what was already changed. A
run that altered something and then lost the device is never presented as one that did
nothing.

## Why one change and not several

Every configuration change a device makes is an event this system reacts to. If the
engine corrected three secrets as three separate changes, it would emit three events and
trigger three more runs — the device in the worst shape would cause the most churn. One
change means one event, and the run that follows finds everything correct and stops.

## Dry runs

`--dry-run` reports exactly what a real run would correct and changes nothing. You can
trust the two to agree because they are not separate code paths: both call the same
step to decide, both then build the change and ask the device what it would do, and only
a real run commits it. That last part is why a dry run can also tell you it *would be
refused* — it gets the same answer from the device that a real run would act on, rather
than predicting one.

What a dry run shows you is therefore the **device's** account of the change, not the
engine's intention. The intention is the one thing nobody needs checked.

One thing to expect: getting that account requires putting the proposed configuration on
the device, so a dry run leaves candidate files in the device's filesystem. Its running
and stored configuration are untouched — that is the promise — but the filesystem is not
pristine, and you should not be surprised to find them.

Nothing is ever cleaned up, and that is deliberate. Discarding a staged change is itself
a configuration change on this platform, so tidying up would emit exactly the events the
system reacts to — a dry run would trigger the assurance run it exists to help you
avoid. Every run therefore leaves the same two files in the same place, and you never
have to work out which kind of run put them there.

## What it does not do

It does not authenticate its callers. Anyone who can reach the request interface can ask
it to check or correct a device. That is why it listens on localhost, and why
authenticating callers sits on the [roadmap backlog](../docs/roadmap.md).

It handles local-user secrets only. Enable secrets, community strings, and shared keys
are on the same backlog; the engine ignores what it does not understand rather than
guessing at it.

Its own device credentials come from the environment, never a command line and never the
inventory file — which is what makes `inventory.yaml` safe to commit.
