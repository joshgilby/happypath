import { generateSecret, verifySecret } from "./secrets.js";
import { getSecret } from "./vault.js";

function reply(response, status, body) {
  response.writeHead(status, { "content-type": "application/json" });
  response.end(JSON.stringify(body));
}

async function readJsonBody(request) {
  const chunks = [];
  for await (const chunk of request) {
    chunks.push(chunk);
  }
  return JSON.parse(chunks.join(""));
}

// Works out what to say about one request. Returns a verdict or a hash; throws if it
// cannot decide, which the caller turns into the cannot-answer outcome.
function evaluate(passphrase, path, body) {
  const secret = getSecret(passphrase, body.service, body.username);

  // No secret recorded means we make no claim about the hash at all. This is an
  // answer, and it is emphatically not "invalid".
  if (secret === null) {
    return { verdict: "unknown" };
  }

  if (path === "/replacement") {
    return { hash: generateSecret(body.format, secret) };
  }

  const matches = verifySecret(body.format, secret, body.hash);
  return { verdict: matches ? "valid" : "invalid" };
}

// The passphrase is supplied once, when the handler is built. It never arrives in a
// request.
export function createHandler(passphrase) {
  return async function handle(request, response) {
    const body = await readJsonBody(request);

    let answer;
    try {
      answer = evaluate(passphrase, request.url, body);
    } catch (error) {
      // A locked vault, an unknown format, anything at all: if we could not work out
      // the answer, we say so rather than guessing. The reply carries no verdict
      // field, so a caller reading one finds nothing rather than something wrong.
      reply(response, 503, { error: error.message });
      return;
    }

    reply(response, 200, answer);
  };
}
