// Runs the verification service.
//
//   QUELAAG_VAULT_KEY=... npm start
//
// The vault passphrase comes from the environment, read once here. It is never part
// of a request.

import { createServer } from "node:http";

import { createHandler } from "./service.js";
import { listEntries } from "./vault.js";

const passphrase = process.env.QUELAAG_VAULT_KEY;
const host = process.env.QUELAAG_SERVICE_HOST ?? "localhost";
const port = process.env.QUELAAG_SERVICE_PORT ?? 8474;

// Open the vault before listening. A service started with the wrong key would
// otherwise run happily and answer "cannot answer" to everything, which an operator
// might not notice for hours.
try {
  listEntries(passphrase);
} catch (error) {
  console.error(`cannot start: ${error.message}`);
  process.exit(1);
}

createServer(createHandler(passphrase)).listen(port, host, () => {
  console.log(`verification service listening on ${host}:${port}`);
});
