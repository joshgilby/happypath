import {
  createCipheriv,
  createDecipheriv,
  randomBytes,
  scryptSync,
} from "node:crypto";
import { mkdirSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { dirname, join } from "node:path";

const OWNER_ONLY_FILE = 0o600;
const OWNER_ONLY_DIRECTORY = 0o700;

function vaultPath() {
  return process.env.QUELAAG_VAULT_PATH ?? join(homedir(), ".quelaag", "vault.json");
}

function readEnvelope() {
  try {
    return JSON.parse(readFileSync(vaultPath(), "utf8"));
  } catch (error) {
    // A vault that isn't there yet behaves like an empty one. A vault that is there
    // but cannot be read is a different situation entirely, and saying "no secrets
    // recorded" about it would hide a real problem.
    if (error.code === "ENOENT") {
      return null;
    }
    throw error;
  }
}

function readEntries(passphrase) {
  const envelope = readEnvelope();
  if (envelope === null) {
    return {};
  }

  const key = scryptSync(passphrase, Buffer.from(envelope.salt, "base64"), 32);
  const decipher = createDecipheriv(
    "aes-256-gcm",
    key,
    Buffer.from(envelope.iv, "base64"),
  );
  decipher.setAuthTag(Buffer.from(envelope.tag, "base64"));

  try {
    const plain = Buffer.concat([
      decipher.update(Buffer.from(envelope.data, "base64")),
      decipher.final(),
    ]);
    return JSON.parse(plain.toString("utf8"));
  } catch {
    // The authentication tag did not check out, which for a file we wrote
    // ourselves means the passphrase is wrong.
    throw new Error("that key does not open this vault");
  }
}

function writeEntries(passphrase, entries) {
  const envelope = readEnvelope();
  const salt = envelope ? Buffer.from(envelope.salt, "base64") : randomBytes(16);
  const key = scryptSync(passphrase, salt, 32);
  const iv = randomBytes(12);

  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const data = Buffer.concat([
    cipher.update(JSON.stringify(entries), "utf8"),
    cipher.final(),
  ]);

  const path = vaultPath();
  mkdirSync(dirname(path), { recursive: true, mode: OWNER_ONLY_DIRECTORY });

  // Write beside the vault and rename over it: a rename is atomic, so an
  // interrupted write leaves the previous vault whole rather than truncated.
  const pending = `${path}.pending`;
  writeFileSync(
    pending,
    JSON.stringify({
      salt: salt.toString("base64"),
      iv: iv.toString("base64"),
      tag: cipher.getAuthTag().toString("base64"),
      data: data.toString("base64"),
    }),
    { mode: OWNER_ONLY_FILE },
  );
  renameSync(pending, path);
}

// Entries nest by service and then username, so a name containing a space — or
// any other character — can never be mistaken for a different entry.
export function putSecret(passphrase, service, username, secret) {
  const entries = readEntries(passphrase);
  entries[service] = { ...entries[service], [username]: secret };
  writeEntries(passphrase, entries);
}

export function getSecret(passphrase, service, username) {
  return readEntries(passphrase)[service]?.[username] ?? null;
}

export function listEntries(passphrase) {
  const entries = readEntries(passphrase);
  return Object.keys(entries).flatMap((service) =>
    Object.keys(entries[service]).map((username) => ({ service, username })),
  );
}
