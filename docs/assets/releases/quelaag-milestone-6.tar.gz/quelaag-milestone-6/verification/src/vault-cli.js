// Record, retrieve, and list the secrets devices are supposed to have.
//
// The passphrase comes from QUELAAG_VAULT_KEY and secrets arrive on standard
// input: command-line arguments are readable by every user on the host.
//
//   printf 'the-secret' | QUELAAG_VAULT_KEY=... node verification/src/vault-cli.js put r1 admin
//   QUELAAG_VAULT_KEY=... node verification/src/vault-cli.js get r1 admin
//   QUELAAG_VAULT_KEY=... node verification/src/vault-cli.js list

import { getSecret, listEntries, putSecret } from "./vault.js";

const passphrase = process.env.QUELAAG_VAULT_KEY;
const [verb, service, username] = process.argv.slice(2);

async function readStdin() {
  const chunks = [];
  for await (const chunk of process.stdin) {
    chunks.push(chunk);
  }
  return chunks.join("");
}

try {
  if (verb === "put") {
    putSecret(passphrase, service, username, await readStdin());
  } else if (verb === "get") {
    const secret = getSecret(passphrase, service, username);
    if (secret === null) {
      console.log(`no secret recorded for ${service} ${username}`);
    } else {
      console.log(secret);
    }
  } else if (verb === "list") {
    const entries = listEntries(passphrase);
    if (entries.length === 0) {
      console.log("the vault holds no secrets");
    }
    for (const entry of entries) {
      console.log(`${entry.service} ${entry.username}`);
    }
  }
} catch (error) {
  console.error(error.message);
  process.exit(1);
}
