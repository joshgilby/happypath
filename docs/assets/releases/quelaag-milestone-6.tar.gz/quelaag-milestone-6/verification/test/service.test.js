import assert from "node:assert/strict";
import { createServer } from "node:http";
import { chmodSync, mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";

import { createHandler } from "../src/service.js";
import { generateSecret } from "../src/secrets.js";
import { putSecret } from "../src/vault.js";

const KEY = "CHANGE-ME-VAULT-KEY";
const ADMIN = "CHANGE-ME-ADMIN";
const OPERATOR = "CHANGE-ME-OPERATOR";

// Everything the service emits during the suite, so one test can prove no secret
// ever appears in any of it.
const emitted = [];

function useTemporaryVault() {
  const directory = mkdtempSync(join(tmpdir(), "quelaag-service-"));
  process.env.QUELAAG_VAULT_PATH = join(directory, "test.vault.json");
  return directory;
}

// Starts the service on a port the operating system picks, so tests never collide
// with each other or with a running service.
async function ask(path, body, passphrase = KEY) {
  const server = createServer(createHandler(passphrase));
  await new Promise((resolve) => server.listen(0, "localhost", resolve));

  const response = await fetch(`http://localhost:${server.address().port}${path}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  const text = await response.text();
  server.close();

  emitted.push(text);
  return { status: response.status, body: JSON.parse(text) };
}

test("a hash from the recorded secret is valid; one from another secret is not", async () => {
  useTemporaryVault();
  putSecret(KEY, "r1", "admin", ADMIN);
  putSecret(KEY, "r1", "operator", OPERATOR);

  // Every pairing of the distinct secret values, not a sample.
  const entries = [
    { username: "admin", secret: ADMIN },
    { username: "operator", secret: OPERATOR },
  ];
  for (const entry of entries) {
    for (const other of entries) {
      const hash = generateSecret("type8", other.secret);
      const { body } = await ask("/verify", {
        service: "r1",
        username: entry.username,
        format: "type8",
        hash,
      });
      assert.equal(body.verdict, entry.secret === other.secret ? "valid" : "invalid");
    }
  }
});

test("two accounts sharing a secret verify against each other", async () => {
  useTemporaryVault();
  putSecret(KEY, "r1", "admin", ADMIN);
  putSecret(KEY, "r2", "admin", ADMIN);

  // The service checks secrets, not identity. This is correct, not a failure.
  const hash = generateSecret("type8", ADMIN);
  const { body } = await ask("/verify", {
    service: "r2",
    username: "admin",
    format: "type8",
    hash,
  });

  assert.equal(body.verdict, "valid");
});

test("an unrecorded account is unknown, never invalid", async () => {
  useTemporaryVault();
  putSecret(KEY, "r1", "admin", ADMIN);

  const hash = generateSecret("type8", ADMIN);
  const { status, body } = await ask("/verify", {
    service: "r9",
    username: "nobody",
    format: "type8",
    hash,
  });

  assert.equal(status, 200);
  assert.equal(body.verdict, "unknown");
});

test("an empty vault answers unknown, not cannot-answer", async () => {
  useTemporaryVault();

  const { status, body } = await ask("/verify", {
    service: "r1",
    username: "admin",
    format: "type8",
    hash: generateSecret("type8", ADMIN),
  });

  assert.equal(status, 200);
  assert.equal(body.verdict, "unknown");
});

test("a replacement hash verifies, and differs every time", async () => {
  useTemporaryVault();
  putSecret(KEY, "r1", "admin", ADMIN);

  const first = await ask("/replacement", { service: "r1", username: "admin", format: "type8" });
  const second = await ask("/replacement", { service: "r1", username: "admin", format: "type8" });

  assert.ok(first.body.hash);
  assert.equal(first.body.verdict, undefined);
  assert.notEqual(first.body.hash, second.body.hash);

  for (const { body } of [first, second]) {
    const check = await ask("/verify", {
      service: "r1",
      username: "admin",
      format: "type8",
      hash: body.hash,
    });
    assert.equal(check.body.verdict, "valid");
  }
});

test("a replacement for an unrecorded account is unknown, with no hash", async () => {
  useTemporaryVault();

  const { status, body } = await ask("/replacement", {
    service: "r9",
    username: "nobody",
    format: "type8",
  });

  assert.equal(status, 200);
  assert.equal(body.verdict, "unknown");
  assert.equal(body.hash, undefined);
});

test("a locked vault cannot be answered, on either operation", async () => {
  useTemporaryVault();
  putSecret(KEY, "r1", "admin", ADMIN);

  for (const path of ["/verify", "/replacement"]) {
    const { status, body } = await ask(
      path,
      { service: "r1", username: "admin", format: "type8", hash: generateSecret("type8", ADMIN) },
      "WRONG-KEY",
    );

    assert.equal(status, 503);
    assert.ok(body.error);
    assert.equal(body.verdict, undefined, "a cannot-answer reply carries no verdict");
    assert.equal(body.hash, undefined);
  }
});

test("an unreadable vault cannot be answered", async () => {
  const directory = useTemporaryVault();
  putSecret(KEY, "r1", "admin", ADMIN);
  chmodSync(directory, 0o000);

  const { status, body } = await ask("/verify", {
    service: "r1",
    username: "admin",
    format: "type8",
    hash: generateSecret("type8", ADMIN),
  });
  chmodSync(directory, 0o700);

  assert.equal(status, 503);
  assert.equal(body.verdict, undefined);
});

test("a format the service cannot handle is not given a verdict", async () => {
  useTemporaryVault();
  putSecret(KEY, "r1", "admin", ADMIN);

  const { status, body } = await ask("/verify", {
    service: "r1",
    username: "admin",
    format: "type9",
    hash: generateSecret("type8", ADMIN),
  });

  assert.equal(status, 503);
  assert.equal(body.verdict, undefined, "an unknown format must not produce a verdict");
});

test("two independent instances answer identically", async () => {
  useTemporaryVault();
  putSecret(KEY, "r1", "admin", ADMIN);
  const hash = generateSecret("type8", ADMIN);

  // Each ask() builds its own handler and server, so these are separate instances.
  const first = await ask("/verify", { service: "r1", username: "admin", format: "type8", hash });
  const second = await ask("/verify", { service: "r1", username: "admin", format: "type8", hash });

  assert.deepEqual(first.body, second.body);
});

test("no secret appears in anything the service emitted", () => {
  // Runs last, over everything the earlier tests captured.
  for (const output of emitted) {
    for (const secret of [ADMIN, OPERATOR, KEY]) {
      assert.ok(!output.includes(secret), `${secret} must not appear in a response`);
    }
  }
});
