import assert from "node:assert/strict";
import { chmodSync, mkdtempSync, readFileSync, statSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";

const KEY = "CHANGE-ME-VAULT-KEY";

// Every test gets its own vault in a temporary directory, so the suite can
// never read or write an operator's real vault.
function useTemporaryVault() {
  const directory = mkdtempSync(join(tmpdir(), "quelaag-vault-"));
  process.env.QUELAAG_VAULT_PATH = join(directory, "test.vault.json");
  return { directory, path: process.env.QUELAAG_VAULT_PATH };
}

// Imported fresh per test file; the module reads the path at call time.
const { putSecret, getSecret, listEntries } = await import("../src/vault.js");

test("a recorded secret comes back", () => {
  useTemporaryVault();
  putSecret(KEY, "r1", "admin", "CHANGE-ME-ADMIN");

  assert.equal(getSecret(KEY, "r1", "admin"), "CHANGE-ME-ADMIN");
});

test("recording again replaces the previous value", () => {
  const { path } = useTemporaryVault();
  putSecret(KEY, "r1", "admin", "CHANGE-ME-ADMIN");
  putSecret(KEY, "r1", "admin", "CHANGE-ME-ADMIN-2");

  assert.equal(getSecret(KEY, "r1", "admin"), "CHANGE-ME-ADMIN-2");
  assert.equal(listEntries(KEY).length, 1);
  assert.ok(!readFileSync(path, "utf8").includes("CHANGE-ME-ADMIN"));
});

test("service and username match exactly", () => {
  useTemporaryVault();
  putSecret(KEY, "r1", "admin", "CHANGE-ME-ADMIN");

  assert.equal(getSecret(KEY, "R1", "admin"), null);
  assert.equal(getSecret(KEY, "r1 ", "admin"), null);
  assert.equal(getSecret(KEY, "r1", "Admin"), null);
});

test("the vault file gives nothing away", () => {
  const { path } = useTemporaryVault();
  // Distinctive names on purpose: the file is mostly base64, where a short
  // string like "r1" turns up by coincidence often enough to fail this test
  // about one run in seven. These are long enough for a chance match to be
  // impossible, and they prove the same thing — names are hidden with secrets.
  putSecret(KEY, "router-alpha-nine", "admin-of-record", "CHANGE-ME-ADMIN");
  putSecret(KEY, "router-bravo-four", "operator-on-duty", "CHANGE-ME-OPERATOR");

  const raw = readFileSync(path, "utf8");
  for (const value of [
    "CHANGE-ME-ADMIN",
    "CHANGE-ME-OPERATOR",
    "router-alpha-nine",
    "router-bravo-four",
    "admin-of-record",
    "operator-on-duty",
  ]) {
    assert.ok(!raw.includes(value), `${value} must not appear in the vault file`);
    assert.ok(
      !raw.includes(Buffer.from(value).toString("base64")),
      `${value} must not appear base64-encoded either`,
    );
  }
  assert.deepEqual(Object.keys(JSON.parse(raw)).sort(), ["data", "iv", "salt", "tag"]);
});

test("the vault file is readable only by its owner", () => {
  const { path } = useTemporaryVault();
  putSecret(KEY, "r1", "admin", "CHANGE-ME-ADMIN");

  assert.equal(statSync(path).mode & 0o777, 0o600);
});

test("a failed recording leaves earlier secrets intact", () => {
  const { directory } = useTemporaryVault();
  putSecret(KEY, "r1", "admin", "CHANGE-ME-ADMIN");

  chmodSync(directory, 0o500); // no new files may be created here
  assert.throws(() => putSecret(KEY, "r2", "operator", "CHANGE-ME-OPERATOR"));
  chmodSync(directory, 0o700);

  assert.equal(getSecret(KEY, "r1", "admin"), "CHANGE-ME-ADMIN");
  assert.equal(listEntries(KEY).length, 1);
});

test("secrets survive a reopened vault byte for byte", () => {
  useTemporaryVault();
  const awkward = "line one\nline two\ttabbed  spaced 'quoted' \"double\" ünïcode ✓";
  putSecret(KEY, "r1", "admin", awkward);

  // A fresh read goes back to the file, as a separate run of the tool would.
  assert.equal(getSecret(KEY, "r1", "admin"), awkward);
});

test("each entry returns its own value", () => {
  useTemporaryVault();
  putSecret(KEY, "r1", "admin", "CHANGE-ME-ADMIN");
  putSecret(KEY, "r1", "operator", "CHANGE-ME-OPERATOR");
  putSecret(KEY, "r2", "admin", "CHANGE-ME-ADMIN-R2");

  assert.equal(getSecret(KEY, "r1", "admin"), "CHANGE-ME-ADMIN");
  assert.equal(getSecret(KEY, "r1", "operator"), "CHANGE-ME-OPERATOR");
  assert.equal(getSecret(KEY, "r2", "admin"), "CHANGE-ME-ADMIN-R2");
});

test("an unrecorded entry, an empty vault, and an absent vault are ordinary", () => {
  useTemporaryVault();
  putSecret(KEY, "r1", "admin", "CHANGE-ME-ADMIN");
  assert.equal(getSecret(KEY, "r9", "nobody"), null);

  // A vault path that was never written to.
  useTemporaryVault();
  assert.equal(getSecret(KEY, "r1", "admin"), null);
  assert.deepEqual(listEntries(KEY), []);
});

test("an unreadable vault is not mistaken for an empty one", () => {
  const { directory } = useTemporaryVault();
  putSecret(KEY, "r1", "admin", "CHANGE-ME-ADMIN");

  chmodSync(directory, 0o000);
  assert.throws(() => getSecret(KEY, "r1", "admin"));
  chmodSync(directory, 0o700);

  assert.equal(getSecret(KEY, "r1", "admin"), "CHANGE-ME-ADMIN");
});

test("a wrong key fails distinctly and never looks empty", () => {
  useTemporaryVault();
  putSecret(KEY, "r1", "admin", "CHANGE-ME-ADMIN");

  for (const call of [
    () => getSecret("WRONG-KEY", "r1", "admin"),
    () => listEntries("WRONG-KEY"),
    () => putSecret("WRONG-KEY", "r2", "operator", "CHANGE-ME-OPERATOR"),
  ]) {
    assert.throws(call, /does not open this vault/);
  }
});

test("listing shows every pair and no secrets", () => {
  useTemporaryVault();
  putSecret(KEY, "r1", "admin", "CHANGE-ME-ADMIN");
  putSecret(KEY, "r2", "operator", "CHANGE-ME-OPERATOR");

  const listed = listEntries(KEY);
  assert.deepEqual(
    listed.map((entry) => `${entry.service}/${entry.username}`).sort(),
    ["r1/admin", "r2/operator"],
  );
  assert.ok(!JSON.stringify(listed).includes("CHANGE-ME"));
});
