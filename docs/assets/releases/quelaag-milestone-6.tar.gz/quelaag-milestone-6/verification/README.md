# Verification

Generates and verifies the secret hashes network devices store, and keeps the
known-good secrets those hashes are checked against. The verification service grows
here in a later milestone.

```sh
npm test        # the whole suite, no lab required
```

## Reading a `$8$` string

Ask a Cisco device for its configuration and the local users look like this:

```text
username admin privilege 15 secret 8 $8$6MDQWLA4JAG.pU$2NYhnsjdrF.A2jgvUlpYU9DYJvSHgxAND7unfHGB7WY
```

The password itself is not in there. What you are looking at has three parts,
separated by `$`:

| Part | Example | What it is |
|------|---------|------------|
| `8` | `8` | the format — Cisco's type 8 |
| salt | `6MDQWLA4JAG.pU` | 14 random characters, chosen when the password was set |
| digest | `2NYhnsjdrF.A2jg…` | the result of scrambling the password together with that salt |

The scrambling is PBKDF2 with SHA-256, repeated 20,000 times. It only runs one way:
from the digest you cannot work backwards to the password. What you *can* do is take
a password you suspect is right, scramble it with the same salt, and see whether you
land on the same digest. That is all verification is.

## Why the same password gives a different hash every time

The salt is new every time a password is set. Set the same password on two devices —
or twice on one device — and the salts differ, so the digests differ:

```text
r1: $8$6MDQWLA4JAG.pU$2NYhnsjdrF.A2jgvUlpYU9DYJvSHgxAND7unfHGB7WY
r2: $8$q9UXTeTb16P/M.$p3NFLlH4GzfJzejNAywIiHqPsPsP6AoIlKLm4wpGsf.
```

Both are `CHANGE-ME-ADMIN`. This is deliberate: if hashes were identical for
identical passwords, anyone who stole a configuration could spot which accounts share
a password, and could precompute a giant table of common passwords once and look up
every device against it. The salt makes that table useless, because it would have to
be rebuilt for every salt.

The consequence for us: **you can never compare two hashes to each other.** Asking
"is this the right password?" always means deriving a fresh digest with the stored
salt and comparing that. `verifySecret` does exactly this, and compares in constant
time so that how long the answer takes cannot betray how much of the digest matched.

## The two details that trip up implementations

Both were found by reproducing real device hashes, and both produce a
plausible-looking hash that no device will ever accept:

1. **The salt is not decoded.** Those 14 characters look like base64, and an 80-bit
   salt would indeed encode to 14 characters — so it is tempting to decode them back
   to 10 raw bytes and feed those to PBKDF2. Cisco does not. The 14 characters are
   used as-is, as ASCII.
2. **The alphabet is not standard base64.** Cisco encodes with
   `./0123456789A-Za-z` — it begins with `./` and has no `+` or `/` at the end.
   Standard base64 output has to be translated across, and its `=` padding dropped.

## The vault

A hash on a device is only useful if you know what it *should* be. The vault is where
those known-good secrets live: encrypted on local disk, one entry per service and
username.

```sh
export QUELAAG_VAULT_KEY='your-passphrase'          # never a command-line argument

printf 'CHANGE-ME-ADMIN' | node src/vault-cli.js put r1 admin
node src/vault-cli.js get r1 admin                   # CHANGE-ME-ADMIN
node src/vault-cli.js list                           # r1 admin
```

The whole vault is encrypted as one blob, so the file hides not just the secrets but
which devices and accounts exist at all. Open it and you see four opaque fields:

```json
{"salt":"CjiY3Yyh…","iv":"nfHP2L1f…","tag":"sM6IfOdb…","data":"YMi7AsnA…"}
```

`salt` and `iv` are not secrets — they are the ingredients needed to re-derive the key
and decrypt — while `data` is meaningless without your passphrase. The passphrase
becomes a key through scrypt, which is deliberately slow so that guessing at a stolen
vault file is expensive.

### What this protects, and what it does not

It protects the vault's contents **from anyone who reads the file without the key**.
That is the whole of it. It does not protect against:

- **Anyone who has the key.** The vault is exactly as safe as your passphrase.
- **Anyone who can read the memory of a process that has opened the vault.** While a
  secret is in use it is plaintext in memory.
- **A secret after you retrieve it.** `get` prints to your terminal, where it may sit
  in scrollback. That is the point of the command, not a flaw — but it is worth
  knowing before you run it on a shared screen.

The key lives outside the vault and always will: it arrives in `QUELAAG_VAULT_KEY`
each time you run a command. Environment variables are readable only by your own
account, whereas command-line arguments are readable by every user on the machine —
which is why the passphrase and secrets never appear as arguments.

If the key is wrong, every command says so and stops. It never reports an empty vault
instead: a locked vault and an empty one must never look alike, or the rest of the
system would happily conclude there are no known-good secrets and "correct" devices
toward nothing.

## The service

The library and the vault answer questions locally. The service answers one question
over the network, so the rest of the system can ask it:

```sh
QUELAAG_VAULT_KEY='your-passphrase' npm start     # listens on localhost:8474
```

```sh
curl -X POST localhost:8474/verify -H 'content-type: application/json' \
  -d '{"service":"r1","username":"admin","format":"type8","hash":"$8$…"}'
# {"verdict":"valid"}

curl -X POST localhost:8474/replacement -H 'content-type: application/json' \
  -d '{"service":"r1","username":"admin","format":"type8"}'
# {"hash":"$8$…"}   a fresh hash for the recorded secret
```

The passphrase is read once at startup, and the service opens the vault immediately to
prove it works. A wrong key means it refuses to start — otherwise it would run happily
and be unable to answer anything, which nobody would notice for hours.

### Four answers, and why they are not three

| Answer | What a caller may conclude |
|--------|---------------------------|
| `{"verdict":"valid"}` | the hash was produced by the recorded secret |
| `{"verdict":"invalid"}` | it was not |
| `{"verdict":"unknown"}` | nothing is recorded for that account, so **no claim is made** |
| `503 {"error":…}` | the service could not work out an answer at all |

The last two exist to keep a caller from concluding something false.

**`unknown` is not `invalid`.** A device account quelaag does not manage is not a
device account with a wrong password. Report it as wrong and the next component along
will "fix" a secret nobody asked it to own.

**Being unable to answer is not a verdict**, so the reply carries no `verdict` field at
all — a caller reading one finds nothing rather than something wrong. This is the rule
the service is built around: *never emit a verdict it cannot stand behind*. A locked
vault, an unreadable file, a format it does not know — all become an admission rather
than a guess.

Which leads to the rule for callers: **change a device only on `invalid`.** Neither
`unknown` nor a failure to answer authorises touching anything.

### What the service knows, and what it never does

It never sees a device. It is handed hashes and hands back verdicts; connecting to
routers is somebody else's job.

Plaintext stops here. The service is the only component that opens the vault, and a
secret it reads lives in one function for the length of one request. What leaves is a
verdict or a freshly generated hash — never the secret itself. That is what lets the
assurance engine be trusted with devices while never being trusted with secrets.

It also holds nothing between requests, so it can be restarted or run twice without
any caller noticing.

### What it does not do: authenticate you

There is no authentication in this milestone. **Anyone who can reach the service can
obtain a valid replacement hash for any secret the vault holds.** That is why it binds
to `localhost` and not to every interface. Authenticating callers is on the
[roadmap backlog](../docs/roadmap.md); until then, where it listens *is* the security
boundary.

One more limit worth knowing: the service checks secrets, not identity. Two accounts
sharing a password verify against each other's hashes, because from here they are
indistinguishable. A `valid` verdict says the hash came from the right secret — not
that it came from the right account.

## Supported formats

`type8` is the only format today, and every call names it explicitly:

```js
verifySecret("type8", plaintext, hash);
generateSecret("type8", plaintext);
```

The format is never guessed from the hash string. Support for other formats — type 5,
type 9, other vendors — is on the [roadmap backlog](../docs/roadmap.md); naming the
format at every call is what will let one be added without changing a single existing
caller.
