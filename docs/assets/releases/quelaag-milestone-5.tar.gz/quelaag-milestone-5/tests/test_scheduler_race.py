"""The one instant that tells a single hold of the lock from two.

`Scheduler.work` decides a run is finished and lets go of the device. Doing both under
one hold of the lock is the whole of the correctness argument, and the difference is
invisible in the shape of the code — two `with self.lock:` blocks read just as
reasonably as one, and the suite is otherwise green either way.

The window between them is not something to race for. This test constructs it: a lock
that fires a request at the exact moment the scheduler releases it after a run. That is
the same discipline as the rest of the scheduling tests, which supply a run they release
on demand rather than sleeping and hoping.

Lives in its own file so that it can be carried into the Milestone 5 archive without
the later milestone's tests coming with it.
"""

import time

from assurance.scheduler import Scheduler


class FiresOnRelease:
    """A lock that runs one callback the instant it is released, once armed.

    Wrapping the lock leaves the production code untouched and puts the request where
    no amount of sleeping could reliably place it.
    """

    def __init__(self, lock, fire):
        self._lock = lock
        self._fire = fire
        self.armed = False

    def __enter__(self):
        return self._lock.__enter__()

    def __exit__(self, *exc_info):
        released = self._lock.__exit__(*exc_info)
        if self.armed:
            # Disarm first: the callback takes this same lock, and its own release
            # must not fire anything.
            self.armed = False
            self._fire()
        return released


def test_a_request_landing_between_deciding_and_letting_go_is_not_dropped():
    """FR-030 at the point where it is actually decided.

    Under one hold, the device has already been let go when the lock is released, so
    this request finds it idle and starts a fresh run.

    Split across two holds, the same request arrives while the device still looks busy,
    is accepted as pending, and is then discarded by the hold that lets go — accepted,
    acknowledged, and never performed.
    """
    runs = []

    def run(device, dry_run=False):
        runs.append(device)
        if len(runs) == 1:
            # Fire on the scheduler's next release of the lock, which is the one it
            # takes to decide whether this run was the last.
            scheduler.lock.armed = True

    scheduler = Scheduler(run)
    scheduler.lock = FiresOnRelease(scheduler.lock, lambda: scheduler.request("r1"))

    assert scheduler.request("r1") == "started"

    deadline = time.time() + 5
    while len(runs) < 2 and time.time() < deadline:
        time.sleep(0.01)

    assert runs == ["r1", "r1"], (
        "a request accepted as the run ended was never performed: it was marked pending "
        "by one hold of the lock and discarded by the next"
    )
