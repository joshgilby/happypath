"""Reaching a real device.

Reading is a structured getter, not a parse of printed configuration. Changing is a
merge of the lines we mean to change — never a replacement of the whole configuration —
and the device is asked what the merge would do before it is allowed to happen.
"""

import os

import yaml
from napalm import get_network_driver
from napalm.base.exceptions import NapalmException
from netmiko import NetmikoBaseException

INVENTORY = os.path.join(os.path.dirname(__file__), "inventory.yaml")

# The tooling underneath has two exception families of its own, and neither of them
# inherits from OSError, so a dead socket, a refused login and a timed-out command
# arrive here as three unrelated types. The engine should not have to know that.
UNREACHABLE = (NapalmException, NetmikoBaseException, OSError)


class DeviceUnreachable(Exception):
    """A device could not be reached, or what it holds could not be read."""


def ask(action, *args, **named):
    """Do one thing to a device, in this module's one failure vocabulary."""
    try:
        return action(*args, **named)
    except UNREACHABLE as problem:
        raise DeviceUnreachable(problem) from problem


def managed_devices():
    """The devices this engine manages, and how to reach them.

    Its own function because there are now two questions to ask of the inventory:
    *open this device*, and *is this a device at all* — which the service answers before
    it schedules anything.
    """
    with open(INVENTORY) as handle:
        return yaml.safe_load(handle)


def open_device(name):
    inventory = managed_devices()

    if name not in inventory:
        return None

    entry = inventory[name]
    driver = get_network_driver(entry["platform"])
    # Credentials come from the environment: a command line is readable by everyone
    # on the host, and the inventory file is committed.
    device = driver(
        hostname=entry["hostname"],
        username=os.environ["QUELAAG_DEVICE_USER"],
        password=os.environ["QUELAAG_DEVICE_PASSWORD"],
    )
    ask(device.open)
    return Device(name, device)


class Device:
    """What the engine is allowed to ask of a device, and nothing more."""

    def __init__(self, name, driver):
        self.name = name
        self.driver = driver

    def get_users(self):
        return ask(self.driver.get_users)

    def stage(self, config):
        ask(self.driver.load_merge_candidate, config="\n".join(config) + "\n")

    def what_would_change(self):
        return ask(self.driver.compare_config)

    def commit(self):
        # Commits and writes through to the stored configuration, so the change
        # survives a restart.
        ask(self.driver.commit_config)

    # There is deliberately no discard. Staging costs a device nothing, but discarding
    # a staged change is *itself* a configuration change — the tooling toggles `file
    # prompt quiet` around it — so it emits the very events this system reacts to.
    # A dry run that discarded would set off the assurance run it exists to avoid.
    # Nothing is thrown away, therefore: every run leaves behind the same two files in
    # the same place, holding the change that run built.

    def close(self):
        # Nothing depends on a clean close, and a device that has gone away cannot be
        # asked to close politely. Losing a run's report over it would be absurd.
        try:
            self.driver.close()
        except UNREACHABLE:
            pass
