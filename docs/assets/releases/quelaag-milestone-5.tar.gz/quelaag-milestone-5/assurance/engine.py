"""Works out what is wrong with a device's secrets, and puts them right.

Deciding and applying are separate on purpose. A dry run and a normal run both decide,
and both then build the change and ask the device what it would do; only a normal run
commits it. Because there is one place conclusions are reached and one place the change
is built, a dry run cannot tell you one thing and a real run do another.
"""

import sys
from datetime import datetime, timezone

from assurance.devices import DeviceUnreachable

FORMAT_PREFIXES = {"$8$": "type8"}


def format_of(secret):
    for prefix, name in FORMAT_PREFIXES.items():
        if secret.startswith(prefix):
            return name
    return None


def decide(device, service):
    """Read the device, ask about every secret, and conclude. Touches nothing."""
    findings = []
    for username, user in sorted(device.get_users().items()):
        secret_format = format_of(user["password"])
        finding = (
            service.verdict_for(username, user["password"], secret_format)
            if secret_format
            else "not_checkable"  # cannot be asked about, so nothing may be concluded
        )
        findings.append(
            {
                "username": username,
                "privilege": user["level"],
                "format": secret_format,
                "hash": user["password"],
                "finding": finding,
                "action": "none",
            }
        )
    return findings


def propose(device, service, corrections):
    """Build the one change this run would make and get the device's account of it.

    Nothing is committed here, so a dry run and a normal run arrive at this same point
    by the same route and are told the same thing.
    """
    for finding in corrections:
        finding["replacement"] = service.replacement_for(
            finding["username"], finding["format"]
        )
    # Every replacement first: a failure to obtain one must not leave a device
    # half-changed, so we find out before the device is touched at all.
    if any(f["replacement"] is None for f in corrections):
        return None

    device.stage([f"username {f['username']} secret 8 {f['replacement']}" for f in corrections])
    return device.what_would_change()


def apply_plan(device, service, findings):
    """Correct every secret found wrong, as one change to the device."""
    corrections = [f for f in findings if f["finding"] == "wrong"]
    if not corrections:
        return None

    account = propose(device, service, corrections)
    if account is None:
        set_action(corrections, "no_replacement")
        return None

    # A device that would change anything else — drop a privilege, touch a neighbouring
    # line — is refused here rather than discovered afterwards.
    if not describes_only(account, corrections):
        set_action(corrections, "refused")
        return account

    device.commit()
    try:
        confirm(device, service, corrections)
    except DeviceUnreachable:
        # The change was committed; we simply cannot say yet whether it took.
        set_action(corrections, "applied_unconfirmed")
    return account


def plan_only(device, service, findings):
    """A dry run: build the change and ask the device what it would do, but never
    commit it.

    What gets reported is what the device said, not what the engine intended — which is
    the whole reason a dry run is worth consulting.
    """
    corrections = [f for f in findings if f["finding"] == "wrong"]
    if not corrections:
        return None

    account = propose(device, service, corrections)
    if account is None:
        set_action(corrections, "no_replacement")
        return None

    would = "would_correct" if describes_only(account, corrections) else "would_refuse"
    set_action(corrections, would)
    return account


def confirm(device, service, corrections):
    """Read each corrected secret back and ask again — per secret, because one secret
    failing to verify says nothing about the others in the same change."""
    users = device.get_users()
    for finding in corrections:
        current = users[finding["username"]]["password"]
        verdict = service.verdict_for(finding["username"], current, finding["format"])
        finding["action"] = {
            "correct": "corrected",
            "not_checkable": "applied_unconfirmed",
        }.get(verdict, "failed")


def set_action(findings, action):
    for finding in findings:
        finding["action"] = action


def describes_only(account, corrections):
    """Does the device's account of a change mention nothing but these secrets?"""
    expected = {f"username {f['username']} secret 8 {f['replacement']}" for f in corrections}
    for line in account.splitlines():
        if line.lstrip("+-").strip() not in expected:
            return False
    return True


def report(device_name, dry_run, findings, change=None, read=True):
    """The only thing that leaves the engine, built in one place so that the command
    line and the service can never describe the same run differently."""
    return {
        "device": device_name,
        "at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "dry_run": dry_run,
        "read": read,
        "findings": findings,
        "change": change,
    }


def render(run):
    """Print a run the way an operator reads it.

    One renderer, because there are two callers: a person at a command line, and a
    service printing runs nobody is waiting for (FR-023). Two renderings of one report
    would drift apart, which is the argument FR-019 already makes about dry runs.

    It flushes. A terminal flushes each line on its own, but output redirected to a file
    or collected from a container is block-buffered, so a run's findings would sit
    invisible until enough of them accumulated to fill the buffer. Findings an operator
    cannot see yet are not reported.
    """
    print(f"{run['device']} at {run['at']}{' (dry run)' if run['dry_run'] else ''}")

    if not run["read"]:
        print("  could not inspect this device")
    elif not run["findings"]:
        print("  no local-user secrets to check")
    else:
        for finding in run["findings"]:
            print(
                f"  {finding['username']} (privilege {finding['privilege']}):"
                f" {finding['finding']} — {finding['action']}"
            )

        # The device's own account of the change, rather than the engine's intention.
        if run["change"]:
            print("  the device says this change would do:")
            for line in run["change"].splitlines():
                print(f"    {line}")

    sys.stdout.flush()


def assure(device, service, dry_run=False):
    """One run: read, decide, and — unless this is a dry run — put right what is wrong."""
    try:
        findings = decide(device, service)
    except DeviceUnreachable:
        # We could not look, so we know nothing and we change nothing.
        return report(device.name, dry_run, [], read=False)

    act = plan_only if dry_run else apply_plan
    return report(device.name, dry_run, findings, act(device, service, findings))
