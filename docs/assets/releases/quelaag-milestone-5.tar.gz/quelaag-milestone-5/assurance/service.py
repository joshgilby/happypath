"""The assurance engine, reachable by another program.

    QUELAAG_DEVICE_USER=admin QUELAAG_DEVICE_PASSWORD=... \\
        uv run uvicorn assurance.service:app --host localhost --port 8475

Milestone 6's syslog receiver will name a device here when that device reports a
configuration change. It is answered at once and never made to wait for the run: a
forwarding rule holds no connection open, and a caller kept for a device's whole round
trip is a caller whose own queue backs up behind ours.

Because a queued run has nobody waiting for it, findings are printed here rather than
returned. Callers are not authenticated, which is why this binds to localhost.
"""

from fastapi import FastAPI
from pydantic import BaseModel

from assurance.devices import DeviceUnreachable, managed_devices, open_device
from assurance.engine import assure, render, report
from assurance.scheduler import Scheduler
from assurance.verification import Verification

app = FastAPI()


def run_assurance(device_name, dry_run=False):
    try:
        device = open_device(device_name)
    except DeviceUnreachable:
        render(report(device_name, dry_run, [], read=False))
        return

    run = assure(device, Verification(device_name), dry_run=dry_run)
    device.close()
    render(run)


scheduler = Scheduler(run_assurance)


class AssureRequest(BaseModel):
    device: str
    dry_run: bool = False


@app.post("/assure")
def assure_device(request: AssureRequest):
    """Say what became of the request. The run happens on the engine's own time."""
    # Refused before anything is scheduled: a caller is told now, rather than left to
    # infer it from a run that never reports.
    if request.device not in managed_devices():
        return {"device": request.device, "accepted": "unknown"}

    return {
        "device": request.device,
        "accepted": scheduler.request(request.device, request.dry_run),
    }
