# quelaag

Tool to maintain secrets on network devices.

Quelaag watches the secrets configured on network devices and puts the known-good
value back when one changes — automatically, with no human in the loop. It is built
as a set of small cooperating services and doubles as an article series about
microservice architecture in network automation.

- **Get started**: [lab/README.md](lab/README.md) — run the two-device lab on your
  laptop
- **Verification**: [verification/README.md](verification/README.md) — what a `$8$`
  secret is, the library that reads and writes them, the encrypted vault holding the
  secrets they are checked against, and the service that answers whether a device's
  hash is the right one
- **Assurance**: [assurance/README.md](assurance/README.md) — the engine that reads a
  device, asks that question of every secret it finds, and puts back the ones that are
  wrong
- **The design**: [docs/design.md](docs/design.md) — the whole system on one page
- **The plan**: [docs/roadmap.md](docs/roadmap.md) — milestones, one article each
