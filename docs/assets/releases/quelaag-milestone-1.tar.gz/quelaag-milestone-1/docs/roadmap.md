# Quelaag Roadmap

Quelaag is a tool to maintain secrets on network devices: local user passwords, enable
secrets, SNMP communities, and shared keys, kept current across a fleet.

The tool is broken down into multiple components:

- A network lab that is the target for the tool
- A secrets vault, that encrypts secrets and stores them on local disk
- A secret verification library that supports generating and verifying Cisco type-8 hashes
  initially, with the intent to add support for other formats
- A secret verification service that accepts incoming requests that include a service and
  username along with a hash or encrypted password; it uses the verification library to
  verify encrypted secrets against an entry in the secrets vault
- An assurance engine that accepts incoming requests to verify secrets on a lab device;
  when invoked, it fetches the configuration from the device, verifies the configured
  secrets with the verification service, and applies new configuration to the device when the
  verification fails
- A syslog receiver that processes incoming messages whenever a device configuration changes
  and calls the assurance engine to verify any secrets on the changed device; devices must
  be configured to send syslog messages to the receiver when their configuration changes

The final implementation should automatically detect and correct configured secrets when they
are changed.

This roadmap splits that goal into milestones. **Each milestone is scoped to be exactly one
instructional article**: it delivers something a reader can run end-to-end, and the commits
that build it map to the article's sections (Constitution, Principle IV). A milestone is done
when the deliverable works in the lab substitute with one setup command (Principle V).

Ideas that don't fit a milestone go in the backlog at the bottom. Promoting a backlog item to
a milestone is an owner decision recorded in `docs/decisions.md` (Constitution, Governance).

## Milestone 0 — The design on one page

**Article angle**: designing before building — what problem quelaag solves, the components it
takes to solve it, and how one detect-and-correct cycle flows through them.

**Deliverable**: A high-level design in `docs/design.md`: problem statement, each component's
single responsibility and boundary, a diagram of how the components connect, and the sequence
of one full cycle (device change → syslog → assurance → verification → correction). Alongside
it, the first entries in `docs/decisions.md` (implementation language, lab technology) and a
seeded `docs/glossary.md` with the system's core terms.

This is the one documentation-only milestone: its done-criterion is the design document, not
a runnable deliverable — the one-command-lab rule applies from Milestone 1 onward.

**In scope**: problem statement, component responsibilities and interfaces at boundary level,
component and sequence diagrams, initial glossary terms, first decision-log entries.

**Out of scope**: any code (Milestone 1 onward), detailed design of any single component
(done in each milestone's own spec and plan).

## Milestone 1 — A lab anyone can run

**Article angle**: "You don't need a rack of routers" — building a disposable network lab a
reader can start on a laptop with one command.

**Deliverable**: A lab substitute (mock device or containerlab topology) starts with a single
documented command, and a first script connects to a lab device and lists its local users.

**In scope**: lab definition and setup command, first device connection, reading and printing
the device's configured users.

**Out of scope**: changing anything on the device (Milestone 5), reacting to device changes
automatically (Milestone 6).

## Milestone 2 — Reading the `$8$`: a verification library

**Article angle**: Milestone 1 ends with user entries like `password 8 $8$...` on screen —
what is that string? How Cisco type-8 (PBKDF2-SHA256) hashes work, and a small library that
generates and verifies them.

**Deliverable**: A library with two operations — generate a type-8 hash from a plaintext, and
verify a plaintext against a type-8 hash — demonstrated against a real hash taken from a lab
device's configuration.

**In scope**: parsing the type-8 format (salt and digest), PBKDF2-SHA256 generation,
verification, a demonstration against the Milestone 1 lab.

**Out of scope**: hash formats beyond type-8 (backlog — this planned extension is why the
library's interface takes a format rather than assuming type-8), any network service around
the library (Milestone 4).

## Milestone 3 — A vault for known-good secrets

**Article angle**: the source of truth — an encrypted store on local disk holding the
plaintext secrets each device is *supposed* to have.

**Deliverable**: A vault that initializes, stores, and retrieves secrets keyed by service and
username, encrypted at rest on local disk, driven by a small CLI.

**In scope**: encryption-at-rest choice (recorded in `docs/decisions.md`), the
service-plus-username keying scheme, put and get operations.

**Out of scope**: external secret stores (backlog), secret history/versioning (backlog),
serving lookups over the network (Milestone 4).

## Milestone 4 — The verification service

**Article angle**: composing the pieces — a small service that answers one question: "is this
hash the right one for this user?"

**Deliverable**: A running service that accepts a request containing a service name, a
username, and a hash (or encrypted password); it looks up the expected secret in the vault,
checks the hash with the verification library, and answers valid or invalid. Demonstrated
with requests built from real lab-device hashes.

**In scope**: request and response format, vault lookup, verification-library call, running
the service alongside the lab.

**Out of scope**: talking to devices (Milestone 5), authenticating callers of the service
itself (backlog).

## Milestone 5 — The assurance engine

**Article angle**: acting on the answer — fetching a device's configuration, checking every
configured secret, and fixing the ones that are wrong.

**Deliverable**: An engine that, invoked for a device, fetches its configuration, extracts
the configured local-user secrets, verifies each against the verification service, and
applies corrected configuration for any that fail. Demonstrated by mis-setting a password on
a lab device by hand and watching the engine restore it.

**In scope**: configuration fetch, secret extraction, verification calls, applying corrected
configuration, re-verifying after the fix.

**Out of scope**: being triggered automatically (Milestone 6), secret types beyond local
user passwords (backlog).

## Milestone 6 — Closing the loop with syslog

**Article angle**: from tool to system — devices report their own configuration changes, and
quelaag detects and corrects a changed secret with no human in the loop.

**Deliverable**: A syslog receiver plus the device configuration that sends it config-change
messages; changing a secret by hand on a lab device leads, within moments, to automatic
detection and correction. The finale demo of the whole system.

**In scope**: configuring lab devices to emit config-change syslog, receiving and parsing
messages to identify the changed device, invoking the assurance engine, the end-to-end
demonstration.

**Out of scope**: scheduled full-fleet sweeps (backlog), notifications to humans (backlog).

## Backlog (unscheduled)

Not planned into any milestone. Each item needs a decision-log entry before work starts.

- Hash formats beyond Cisco type-8: type-5 (MD5), type-9 (scrypt), other vendors' formats.
- Secret types beyond local user passwords: enable secrets, SNMP communities, TACACS+/RADIUS
  keys.
- Authenticating callers of the verification service.
- Concurrent fleet runs.
- Independent deployment: giving each component its own demonstrated development, testing,
  and deployment lifecycle.
- Resilience between services: timeouts, retries, and what the assurance engine does when
  the verification service is down — failure handling enters only as an explicitly stated
  requirement (Constitution, Principle II).
- Observability: tracing one detect-and-correct cycle across the services, plus logs and
  metrics — requires explicitly requested logging (Constitution, Code Style Constraints).
- Integration with external secret stores (HashiCorp Vault, cloud secret managers).
- Secret history and versioning in the store.
- Scheduled assurance runs and change notifications.
