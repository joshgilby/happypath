#!/bin/sh
# Tear the quelaag lab down, removing everything up.sh created.
cd "$(dirname "$0")"
sudo containerlab destroy -t topology.clab.yml --cleanup
