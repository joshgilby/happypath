# The Quelaag Lab

A disposable two-device network lab that runs on your laptop. You bring one thing —
a Cisco image you download yourself — and everything else is one command at a time.

## Prerequisites

Check these before starting:

- **Linux host** — native, or Windows via WSL2
- **Docker** — 24 or newer (`docker --version`)
- **containerlab** — 0.60 or newer (`containerlab version`)
- **unzip** — 6.0 or newer (`unzip -v`). Cisco ships the reference platform ISO inside
  a zip, and 6.0 is what every current distribution carries
- **GNU make** — 4.0 or newer (`make --version`). The image build runs it
- **uv** — 0.5 or newer (`uv --version`); uv reads the Python version floor from
  `pyproject.toml` and installs the exact dependencies pinned in `uv.lock` on first
  run — you never manage a virtualenv yourself
- **Node** — 20 or newer (`node --version`), from Milestone 2 onward. The JavaScript
  here has no runtime dependencies and no build step, so the floor is set by the tests:
  they use Node's built-in runner, which is stable from 20
- **~4 GB of free memory** for the lab, and `sudo` (containerlab and the image build
  use it)

## The image is bring-your-own

The lab devices run Cisco IOL, which Cisco distributes in the **reference platform
ISO of CML-Free** — free with a Cisco account at <https://developer.cisco.com/modeling-labs/>.
The images are licensed for use within CML; this repository therefore never contains
or redistributes them, and the `.gitignore` blocks them from ever being committed.
You download the ISO with your own account, and the build script does the rest.

## Your path, in order

**1. Prepare the image** (once). Cisco delivers the reference platform ISO as a
zipped download — unzip it first, then:

```sh
unzip ~/Downloads/refplat-<version>-free-iso.zip -d ~/Downloads
./lab/build-image.sh ~/Downloads/refplat-<version>-free.iso
```

**2. Start the lab**:

```sh
./lab/up.sh
```

Both devices boot their baseline configuration and accept SSH at `192.0.2.11` (r1)
and `192.0.2.12` (r2).

**3. Run the first script**:

```sh
uv run scripts/list_users.py r1
```

When you're done:

```sh
./lab/down.sh
```

## Rebooting a device

```sh
uv run scripts/reboot_device.py r1
```

**Do not use `docker restart` for this.** It restarts the *container*, which leaves
`iol.bin` running without `iouyap` — the daemon that bridges the device's interfaces to
the container's `eth0` — and destroys the veth pair carrying the data link between r1
and r2. The device boots normally and is simply cut off from the network, which is
indistinguishable from a hang. Recovering it needs a full `down.sh && up.sh`.

`reboot_device.py` reloads IOS instead. The container and all of containerlab's
plumbing are untouched: `iol.bin` re-execs in place, `iouyap` keeps running, and the
device comes back on the same container in a couple of minutes. That is a real reboot,
and the only kind this lab can offer.

Two quirks it works around, both IOL-specific:

- IOL refuses `reload` over SSH unless the configuration register's boot bits are
  non-zero, so the script sets `config-register 0x2102` first.
- IOL does not keep the register across a boot. It never appears in the running or
  startup configuration and reads back as `0x0` every time, so it cannot be set once in
  the baseline — it has to be set immediately before each reload.

And note what a **redeploy** does, since it is easy to mistake for a reboot:
`down.sh` runs `containerlab destroy --cleanup`, which deletes `lab/clab-quelaag/` —
the directory holding each node's `nvram_000NN` and `boot_config.txt`. `up.sh` then
regenerates the boot config from `topology.clab.yml` and `configs/rN.partial.cfg`, whose
secrets are in plaintext for the device to hash afresh. A redeploy therefore always
returns a device to baseline, whatever was configured on it. That is what makes the lab
reproducible, and it means a redeploy can never demonstrate that anything persisted.

## Lab credentials (authoritative list)

Every credential in this lab is a documented fake — knowing them compromises
nothing. Other files reference this table rather than restating it.

| Username | Password | Privilege | Notes |
|----------|----------|-----------|-------|
| admin | `CHANGE-ME-ADMIN` | 15 | baseline |
| operator | `CHANGE-ME-OPERATOR` | 1 | baseline |
| roundtrip | `CHANGE-ME-ROUNDTRIP` | 1 | exists only while `scripts/roundtrip_check.py` runs |

On the devices these are stored as type-8 hashes — run the first script and you'll
see them.
