#!/bin/sh
# Start the quelaag lab: two IOL devices booting their baseline configurations.
cd "$(dirname "$0")"
sudo containerlab deploy -t topology.clab.yml
