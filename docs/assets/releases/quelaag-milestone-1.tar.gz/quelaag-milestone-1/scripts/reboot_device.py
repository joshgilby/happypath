"""Reboot a lab device, the way this lab can actually reboot one.

Usage: uv run scripts/reboot_device.py r1

`docker restart` is not a device reboot. It restarts the *container*, which leaves
`iol.bin` running without `iouyap` — the daemon bridging the device's interfaces to the
container's `eth0` — and destroys the veth pair carrying the data link. The device boots
fine and is simply cut off from the network, which looks exactly like a hang.

Reloading IOS instead leaves the container and all its plumbing untouched: the process
re-execs in place, `iouyap` keeps running, and the device comes back on the same
`docker` instance. That is a real reboot, and it is what verifying anything about
persistence requires.

One quirk to know: IOL refuses `reload` from an SSH session unless the configuration
register's boot bits are non-zero, and it does not keep the register across a boot —
`config-register` never appears in the running or startup configuration, and reads back
as `0x0` every time. So the register has to be set immediately before each reload; it
cannot be put in the baseline configuration once.
"""

import sys
import time

from netmiko import ConnectHandler, NetmikoBaseException

# Losing the session is what a successful reload looks like from here, so these are
# the expected outcome rather than errors.
LOST_SESSION = (NetmikoBaseException, OSError, EOFError)

DEVICES = {
    "r1": "192.0.2.11",
    "r2": "192.0.2.12",
}

# The lab's documented fake credentials — the authoritative list is in lab/README.md.
USERNAME = "admin"
PASSWORD = "CHANGE-ME-ADMIN"


def connect(address):
    return ConnectHandler(
        device_type="cisco_xe", host=address, username=USERNAME, password=PASSWORD
    )


def reload_device(address):
    device = connect(address)
    device.send_config_set(["config-register 0x2102"], cmd_verify=False)

    # Timed sends rather than prompt matches, because the device stops answering
    # partway through — the session dies as the reload begins, which is the point.
    try:
        output = device.send_command_timing("reload")
        if "yes/no" in output.lower():
            # Answer "no": whatever is worth keeping was saved before this script ran,
            # and saving here would hide a device that failed to write its own
            # configuration — exactly what a persistence check is looking for.
            output = device.send_command_timing("no")
        if "confirm" in output.lower():
            device.send_command_timing("")
    except LOST_SESSION:
        pass


def wait_until_back(address, timeout=1200):
    deadline = time.time() + timeout
    while time.time() < deadline:
        time.sleep(15)
        try:
            device = connect(address)
        except LOST_SESSION:
            continue
        device.disconnect()
        return True
    return False


def main():
    name = sys.argv[1]
    address = DEVICES[name]

    print(f"{name}: reloading")
    reload_device(address)

    print(f"{name}: waiting for it to come back (this takes a few minutes)")
    if wait_until_back(address):
        print(f"{name}: back")
    else:
        print(f"{name}: did not come back in time")
        sys.exit(1)


if __name__ == "__main__":
    main()
