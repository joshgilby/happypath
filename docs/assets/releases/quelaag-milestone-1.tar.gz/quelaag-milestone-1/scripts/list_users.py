"""Print the local users configured on a lab device.

Usage: uv run scripts/list_users.py r1
"""

import sys

from netmiko import ConnectHandler

DEVICES = {
    "r1": "192.0.2.11",
    "r2": "192.0.2.12",
}

# The lab's documented fake credentials — the authoritative list is in lab/README.md.
USERNAME = "admin"
PASSWORD = "CHANGE-ME-ADMIN"


def fetch_username_lines(device_name):
    connection = ConnectHandler(
        device_type="cisco_xe",
        host=DEVICES[device_name],
        username=USERNAME,
        password=PASSWORD,
    )
    output = connection.send_command("show running-config | include ^username")
    connection.disconnect()
    return output.splitlines()


def main():
    device_name = sys.argv[1]
    for line in fetch_username_lines(device_name):
        # A username line reads: username <name> privilege <n> secret 8 <hash>
        words = line.split()
        name = words[1]
        secret_hash = words[-1]
        print(f"{device_name}: username {name}, secret 8 {secret_hash}")


if __name__ == "__main__":
    main()
