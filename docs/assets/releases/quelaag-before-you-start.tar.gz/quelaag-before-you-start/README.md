# quelaag — building the lab device image

This download does one thing: it turns the CML-Free reference platform ISO into the
container image that every later article's lab runs on. Do it once and never again.

You bring the ISO. This project cannot ship it — Cisco licenses the images for use
within CML — so you download it yourself, free, with a Cisco account at
<https://developer.cisco.com/modeling-labs/>. Allow about thirty minutes, most of it
download.

```sh
unzip ~/Downloads/refplat-<version>-free-iso.zip -d ~/Downloads
./lab/build-image.sh ~/Downloads/refplat-<version>-free.iso
```

It ends by printing `Image ready: quelaag/cisco_iol:lab`.

- `lab/README.md` — prerequisites and their exact minimum versions. Check these first
- `lab/build-image.sh` — the build itself, about thirty lines, `sudo` for the mount
- `.gitignore` — blocks the ISO, the extracted binary and the vrnetlab clone from ever
  being committed, should you keep this alongside your own work

The lab is not in here. The topology, `up.sh`, `down.sh` and the two device
configurations arrive with article 1, which is where they are explained. This archive
is only the prerequisite that article assumes you already did.
