# The Quelaag Lab

A disposable two-device network lab that runs on your laptop. You bring one thing —
a Cisco image you download yourself — and everything else is one command at a time.

## Prerequisites

Check these before starting:

- **Linux host** — native, or Windows via WSL2
- **Docker** — 24 or newer (`docker --version`)
- **containerlab** — 0.60 or newer (`containerlab version`)
- **uv** — 0.5 or newer (`uv --version`); uv reads the Python version floor from
  `pyproject.toml` and installs the exact dependencies pinned in `uv.lock` on first
  run — you never manage a virtualenv yourself
- **~4 GB of free memory** for the lab, and `sudo` (containerlab and the image build
  use it)


## The image is bring-your-own

The lab devices run Cisco IOL, which Cisco distributes in the **reference platform
ISO of CML-Free** — free with a Cisco account at <https://developer.cisco.com/modeling-labs/>.
The images are licensed for use within CML; this repository therefore never contains
or redistributes them, and the `.gitignore` blocks them from ever being committed.
You download the ISO with your own account, and the build script does the rest.

