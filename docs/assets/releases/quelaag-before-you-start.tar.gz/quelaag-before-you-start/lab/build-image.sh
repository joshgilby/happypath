#!/bin/sh
# Turn your CML-Free reference platform ISO into the lab's device image.
#
# You download the ISO yourself with your free Cisco account (see lab/README.md);
# the image is licensed for use within CML and is never committed or redistributed.
#
# Usage: ./lab/build-image.sh <path-to-refplat-iso>
set -e

iso=$1
labdir=$(cd "$(dirname "$0")" && pwd)
mnt=$(mktemp -d)
work=$(mktemp -d)

sudo mount -o loop,ro "$iso" "$mnt"

test -d "$labdir/vrnetlab" || git clone --depth 1 https://github.com/hellt/vrnetlab "$labdir/vrnetlab"

# The reference platform ships IOL as an OCI image archive; the device binary
# is the *.iol file inside the archive's largest layer.
archive=$(find "$mnt/virl-base-images" -name 'iol-xe-*.tar.gz' | grep -v serial | head -n 1)
version=$(basename "$archive" .tar.gz | sed -e 's/^iol-xe-//' -e 's/-/./g')

tar -xzf "$archive" -C "$work"
layer=$(ls -S "$work/blobs/sha256" | head -n 1)
tar -xf "$work/blobs/sha256/$layer" -C "$work" --wildcards '*.iol'
binary=$(find "$work" -maxdepth 1 -type f -name '*.iol')
mv "$binary" "$labdir/vrnetlab/cisco/iol/cisco_iol-$version.bin"

sudo umount "$mnt"
rm -rf "$work"
rmdir "$mnt"

cd "$labdir/vrnetlab/cisco/iol"
make docker-image

built=$(docker images --filter reference='vrnetlab/cisco_iol' --format '{{.Repository}}:{{.Tag}}' | head -n 1)
docker tag "$built" quelaag/cisco_iol:lab

echo "Image ready: quelaag/cisco_iol:lab"
